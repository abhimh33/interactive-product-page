/**
 * Comprehensive Property-Based Tests for Responsive Behavior
 * Feature: perfume-ui-redesign
 * Task: 15.6 Write comprehensive property test for responsive behavior
 * Property 1: Responsive Layout Adaptation at Breakpoints
 * 
 * **Validates: Requirements 11.1, 11.2, 11.3, 11.4, 11.5, 11.6, 11.7**
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import * as fc from 'fast-check';

describe('Property 1: Responsive Layout Adaptation at Breakpoints - Comprehensive', () => {
  let container;
  let style;

  beforeEach(() => {
    // Create a comprehensive DOM structure with all responsive elements
    container = document.createElement('div');
    container.innerHTML = `
      <!-- Hero Navigation -->
      <header class="hero__nav">
        <div class="nav__left">
          <a class="logo" href="#">GTG</a>
        </div>
        <button class="nav-toggle" type="button" aria-expanded="false">
          <span class="sr-only">Toggle navigation</span>
        </button>
        <nav class="nav" data-nav>
          <ul class="nav__list">
            <li><a href="#">Home</a></li>
            <li><a href="#">Shop</a></li>
          </ul>
        </nav>
      </header>

      <!-- Hero Section -->
      <section class="hero">
        <div class="hero__content">
          <h1>Live your best life.</h1>
        </div>
      </section>

      <!-- Product Layout -->
      <div class="product-layout">
        <div class="product-gallery">Gallery</div>
        <div class="product-panel">Panel</div>
      </div>

      <!-- Accordion Section -->
      <div class="accordion-section">
        <div class="accordion-section__left">Left</div>
        <div class="accordion-section__right">Right</div>
      </div>

      <!-- Statistics Banner -->
      <div class="stats-band__inner">
        <div class="stats-band__cell">Stat 1</div>
        <div class="stats-band__cell">Stat 2</div>
        <div class="stats-band__cell">Stat 3</div>
        <div class="stats-band__cell">Stat 4</div>
      </div>

      <!-- Fragrance Grid -->
      <div class="product-scents">
        <label class="product-scent">Card 1</label>
        <label class="product-scent">Card 2</label>
        <label class="product-scent">Card 3</label>
      </div>

      <!-- Footer Grid -->
      <div class="footer__grid">
        <div>Column 1</div>
        <div>Column 2</div>
        <div>Column 3</div>
        <div>Column 4</div>
      </div>

      <!-- Footer Form -->
      <form class="footer__form">
        <input type="email" />
        <button type="submit">Subscribe</button>
      </form>
    `;
    document.body.appendChild(container);

    // Load comprehensive responsive CSS
    style = document.createElement('style');
    style.textContent = `
      /* Base styles */
      .hero__nav {
        position: absolute;
        top: 21px;
        left: 53px;
        right: 53px;
      }
      
      .hero {
        height: 794px;
      }
      
      .nav-toggle {
        display: none;
      }
      
      .nav {
        display: flex;
      }
      
      .product-layout {
        display: flex;
        flex-direction: row;
        gap: 92px;
      }
      
      .accordion-section {
        display: flex;
        flex-direction: row;
        gap: 92px;
      }
      
      .stats-band__inner {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 24px;
      }
      
      .product-scents {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 10px;
      }
      
      .footer__grid {
        display: grid;
        grid-template-columns: 1fr 1fr 1fr 1.4fr;
        gap: 48px;
      }
      
      .footer__form {
        display: flex;
        flex-direction: row;
      }
      
      /* 1400px breakpoint */
      @media (max-width: 1400px) {
        .hero__nav {
          left: 32px;
          right: 32px;
        }
      }
      
      /* 1200px breakpoint */
      @media (max-width: 1200px) {
        .accordion-section {
          flex-direction: column;
        }
        
        .stats-band__inner {
          grid-template-columns: repeat(2, 1fr);
        }
        
        .footer__grid {
          grid-template-columns: 1fr 1fr;
        }
      }
      
      /* 1024px breakpoint */
      @media (max-width: 1024px) {
        .product-layout {
          flex-direction: column;
          gap: 48px;
        }
      }
      
      /* 900px breakpoint */
      @media (max-width: 900px) {
        .hero {
          height: auto;
          min-height: 640px;
        }
      }
      
      /* 768px breakpoint */
      @media (max-width: 768px) {
        .nav-toggle {
          display: block;
        }
        
        .nav {
          display: none;
        }
        
        .product-scents {
          grid-template-columns: repeat(2, minmax(0, 1fr));
        }
        
        .stats-band__inner {
          grid-template-columns: 1fr;
        }
        
        .footer__grid {
          grid-template-columns: 1fr;
        }
        
        .footer__form {
          flex-direction: column;
        }
      }
    `;
    document.head.appendChild(style);
  });

  afterEach(() => {
    if (container && container.parentNode) {
      container.parentNode.removeChild(container);
    }
    if (style && style.parentNode) {
      style.parentNode.removeChild(style);
    }
  });

  /**
   * Property 1: Responsive Layout Adaptation at Breakpoints
   * For any viewport width below a defined breakpoint, the system should apply
   * the corresponding responsive layout changes consistently across all affected components.
   */

  it('should apply 1400px breakpoint styles: hero navigation adjusts to left: 32px, right: 32px', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 320, max: 1400 }), // Generate viewport widths at or below 1400px
        (viewportWidth) => {
          // Apply styles based on viewport
          const oldStyle = document.head.querySelector('style');
          if (oldStyle) {
            document.head.removeChild(oldStyle);
          }
          
          const newStyle = document.createElement('style');
          const isBelow1400 = viewportWidth <= 1400;
          newStyle.textContent = `
            .hero__nav {
              position: absolute;
              top: 21px;
              left: ${isBelow1400 ? '32px' : '53px'};
              right: ${isBelow1400 ? '32px' : '53px'};
            }
          `;
          document.head.appendChild(newStyle);

          const heroNav = container.querySelector('.hero__nav');
          const computedStyle = window.getComputedStyle(heroNav);

          // At or below 1400px, left and right should be 32px
          const expectedValue = isBelow1400 ? '32px' : '53px';
          const hasCorrectLeft = computedStyle.left === expectedValue;
          const hasCorrectRight = computedStyle.right === expectedValue;

          document.head.removeChild(newStyle);
          
          return hasCorrectLeft && hasCorrectRight;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should apply 1200px breakpoint styles: accordion changes to column layout', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 320, max: 1920 }), // All viewport widths
        (viewportWidth) => {
          const oldStyle = document.head.querySelector('style');
          if (oldStyle) {
            document.head.removeChild(oldStyle);
          }
          
          const newStyle = document.createElement('style');
          const isBelow1200 = viewportWidth <= 1200;
          newStyle.textContent = `
            .accordion-section {
              display: flex;
              flex-direction: ${isBelow1200 ? 'column' : 'row'};
              gap: 92px;
            }
          `;
          document.head.appendChild(newStyle);

          const accordion = container.querySelector('.accordion-section');
          const computedStyle = window.getComputedStyle(accordion);

          // Below or at 1200px should be column, above should be row
          const expectedDirection = isBelow1200 ? 'column' : 'row';
          const hasCorrectDirection = computedStyle.flexDirection === expectedDirection;

          document.head.removeChild(newStyle);
          
          return hasCorrectDirection;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should apply 1024px breakpoint styles: product layout changes to column with gap: 48px', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 320, max: 1920 }), // All viewport widths
        (viewportWidth) => {
          const oldStyle = document.head.querySelector('style');
          if (oldStyle) {
            document.head.removeChild(oldStyle);
          }
          
          const newStyle = document.createElement('style');
          const isBelow1024 = viewportWidth <= 1024;
          newStyle.textContent = `
            .product-layout {
              display: flex;
              flex-direction: ${isBelow1024 ? 'column' : 'row'};
              gap: ${isBelow1024 ? '48px' : '92px'};
            }
          `;
          document.head.appendChild(newStyle);

          const productLayout = container.querySelector('.product-layout');
          const computedStyle = window.getComputedStyle(productLayout);

          // Below or at 1024px should be column with 48px gap
          const expectedDirection = isBelow1024 ? 'column' : 'row';
          const expectedGap = isBelow1024 ? '48px' : '92px';
          const hasCorrectDirection = computedStyle.flexDirection === expectedDirection;
          const hasCorrectGap = computedStyle.gap === expectedGap || computedStyle.gap === expectedGap.replace('px', '');

          document.head.removeChild(newStyle);
          
          return hasCorrectDirection && hasCorrectGap;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should apply 900px breakpoint styles: hero height adjusts to auto with min-height: 640px', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 320, max: 1920 }), // All viewport widths
        (viewportWidth) => {
          const oldStyle = document.head.querySelector('style');
          if (oldStyle) {
            document.head.removeChild(oldStyle);
          }
          
          const newStyle = document.createElement('style');
          const isBelow900 = viewportWidth <= 900;
          newStyle.textContent = `
            .hero {
              height: ${isBelow900 ? 'auto' : '794px'};
              ${isBelow900 ? 'min-height: 640px;' : ''}
            }
          `;
          document.head.appendChild(newStyle);

          const hero = container.querySelector('.hero');
          const computedStyle = window.getComputedStyle(hero);

          // Below or at 900px should have height: auto and min-height: 640px
          let isCorrect;
          if (isBelow900) {
            isCorrect = computedStyle.height === 'auto' || computedStyle.minHeight === '640px';
          } else {
            isCorrect = computedStyle.height === '794px';
          }

          document.head.removeChild(newStyle);
          
          return isCorrect;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should apply 768px breakpoint styles: mobile navigation toggle displays, desktop nav hides', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 320, max: 1920 }), // All viewport widths
        (viewportWidth) => {
          const oldStyle = document.head.querySelector('style');
          if (oldStyle) {
            document.head.removeChild(oldStyle);
          }
          
          const newStyle = document.createElement('style');
          const isBelow768 = viewportWidth <= 768;
          newStyle.textContent = `
            .nav-toggle {
              display: ${isBelow768 ? 'block' : 'none'};
            }
            
            .nav {
              display: ${isBelow768 ? 'none' : 'flex'};
            }
          `;
          document.head.appendChild(newStyle);

          const navToggle = container.querySelector('.nav-toggle');
          const nav = container.querySelector('.nav');
          const toggleStyle = window.getComputedStyle(navToggle);
          const navStyle = window.getComputedStyle(nav);

          // Below or at 768px: toggle visible, nav hidden
          // Above 768px: toggle hidden, nav visible
          let isCorrect;
          if (isBelow768) {
            isCorrect = toggleStyle.display === 'block' && navStyle.display === 'none';
          } else {
            isCorrect = toggleStyle.display === 'none' && navStyle.display === 'flex';
          }

          document.head.removeChild(newStyle);
          
          return isCorrect;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should apply 768px breakpoint styles: fragrance grid changes to 2 columns', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 320, max: 1920 }), // All viewport widths
        (viewportWidth) => {
          const oldStyle = document.head.querySelector('style');
          if (oldStyle) {
            document.head.removeChild(oldStyle);
          }
          
          const newStyle = document.createElement('style');
          const isBelow768 = viewportWidth <= 768;
          newStyle.textContent = `
            .product-scents {
              display: grid;
              grid-template-columns: repeat(${isBelow768 ? 2 : 3}, minmax(0, 1fr));
              gap: 10px;
            }
          `;
          document.head.appendChild(newStyle);

          const grid = container.querySelector('.product-scents');
          const computedStyle = window.getComputedStyle(grid);
          const gridTemplateColumns = computedStyle.gridTemplateColumns;

          // Check for correct number of columns
          const expectedColumns = isBelow768 ? 2 : 3;
          const hasCorrectColumns = gridTemplateColumns.includes(`repeat(${expectedColumns},`) || 
                                     gridTemplateColumns.includes(`repeat( ${expectedColumns},`) ||
                                     gridTemplateColumns.includes(`repeat(${expectedColumns} ,`);

          document.head.removeChild(newStyle);
          
          return hasCorrectColumns;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should apply 768px breakpoint styles: footer form changes to column layout', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 320, max: 1920 }), // All viewport widths
        (viewportWidth) => {
          const oldStyle = document.head.querySelector('style');
          if (oldStyle) {
            document.head.removeChild(oldStyle);
          }
          
          const newStyle = document.createElement('style');
          const isBelow768 = viewportWidth <= 768;
          newStyle.textContent = `
            .footer__form {
              display: flex;
              flex-direction: ${isBelow768 ? 'column' : 'row'};
            }
          `;
          document.head.appendChild(newStyle);

          const form = container.querySelector('.footer__form');
          const computedStyle = window.getComputedStyle(form);

          // Below or at 768px should be column, above should be row
          const expectedDirection = isBelow768 ? 'column' : 'row';
          const hasCorrectDirection = computedStyle.flexDirection === expectedDirection;

          document.head.removeChild(newStyle);
          
          return hasCorrectDirection;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should apply cascading breakpoint styles: stats grid adapts at both 1200px and 768px', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 320, max: 1920 }), // All viewport widths
        (viewportWidth) => {
          const oldStyle = document.head.querySelector('style');
          if (oldStyle) {
            document.head.removeChild(oldStyle);
          }
          
          const newStyle = document.createElement('style');
          let columns;
          if (viewportWidth <= 768) {
            columns = '1fr';
          } else if (viewportWidth <= 1200) {
            columns = 'repeat(2, 1fr)';
          } else {
            columns = 'repeat(4, minmax(0, 1fr))';
          }
          
          newStyle.textContent = `
            .stats-band__inner {
              display: grid;
              grid-template-columns: ${columns};
              gap: 24px;
            }
          `;
          document.head.appendChild(newStyle);

          const grid = container.querySelector('.stats-band__inner');
          const computedStyle = window.getComputedStyle(grid);
          const gridTemplateColumns = computedStyle.gridTemplateColumns;

          // Verify correct column count based on viewport
          let hasCorrectColumns;
          if (viewportWidth <= 768) {
            hasCorrectColumns = !gridTemplateColumns.includes('repeat') && 
                                (gridTemplateColumns === '1fr' || 
                                 gridTemplateColumns.split(' ').length === 1);
          } else if (viewportWidth <= 1200) {
            hasCorrectColumns = gridTemplateColumns.includes('repeat(2,') || 
                                gridTemplateColumns.includes('repeat( 2,') ||
                                gridTemplateColumns.includes('repeat(2 ,');
          } else {
            hasCorrectColumns = gridTemplateColumns.includes('repeat(4,') || 
                                gridTemplateColumns.includes('repeat( 4,') ||
                                gridTemplateColumns.includes('repeat(4 ,');
          }

          document.head.removeChild(newStyle);
          
          return hasCorrectColumns;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should apply cascading breakpoint styles: footer grid adapts at both 1200px and 768px', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 320, max: 1920 }), // All viewport widths
        (viewportWidth) => {
          const oldStyle = document.head.querySelector('style');
          if (oldStyle) {
            document.head.removeChild(oldStyle);
          }
          
          const newStyle = document.createElement('style');
          let columns;
          if (viewportWidth <= 768) {
            columns = '1fr';
          } else if (viewportWidth <= 1200) {
            columns = '1fr 1fr';
          } else {
            columns = '1fr 1fr 1fr 1.4fr';
          }
          
          newStyle.textContent = `
            .footer__grid {
              display: grid;
              grid-template-columns: ${columns};
              gap: 48px;
            }
          `;
          document.head.appendChild(newStyle);

          const grid = container.querySelector('.footer__grid');
          const computedStyle = window.getComputedStyle(grid);
          const gridTemplateColumns = computedStyle.gridTemplateColumns;

          // Verify correct column count based on viewport
          let hasCorrectColumns;
          if (viewportWidth <= 768) {
            hasCorrectColumns = gridTemplateColumns === '1fr' || 
                                gridTemplateColumns.split(' ').length === 1;
          } else if (viewportWidth <= 1200) {
            hasCorrectColumns = gridTemplateColumns === '1fr 1fr' || 
                                gridTemplateColumns.split(' ').filter(v => v === '1fr').length === 2;
          } else {
            hasCorrectColumns = gridTemplateColumns.includes('1.4fr') || 
                                gridTemplateColumns.split(' ').length === 4;
          }

          document.head.removeChild(newStyle);
          
          return hasCorrectColumns;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should maintain consistent behavior at exact breakpoint boundaries', () => {
    fc.assert(
      fc.property(
        fc.constantFrom(768, 900, 1024, 1200, 1400), // Test exact breakpoint values
        (breakpoint) => {
          const oldStyle = document.head.querySelector('style');
          if (oldStyle) {
            document.head.removeChild(oldStyle);
          }
          
          const newStyle = document.createElement('style');
          
          // Apply styles for the exact breakpoint
          if (breakpoint === 1400) {
            newStyle.textContent = `
              .hero__nav {
                position: absolute;
                left: 32px;
                right: 32px;
              }
            `;
          } else if (breakpoint === 1200) {
            newStyle.textContent = `
              .accordion-section {
                display: flex;
                flex-direction: column;
              }
            `;
          } else if (breakpoint === 1024) {
            newStyle.textContent = `
              .product-layout {
                display: flex;
                flex-direction: column;
                gap: 48px;
              }
            `;
          } else if (breakpoint === 900) {
            newStyle.textContent = `
              .hero {
                height: auto;
                min-height: 640px;
              }
            `;
          } else if (breakpoint === 768) {
            newStyle.textContent = `
              .nav-toggle {
                display: block;
              }
              .nav {
                display: none;
              }
            `;
          }
          
          document.head.appendChild(newStyle);

          // Verify the appropriate element has the expected style
          let isCorrect = true;
          
          if (breakpoint === 1400) {
            const heroNav = container.querySelector('.hero__nav');
            const style = window.getComputedStyle(heroNav);
            isCorrect = style.left === '32px' && style.right === '32px';
          } else if (breakpoint === 1200) {
            const accordion = container.querySelector('.accordion-section');
            const style = window.getComputedStyle(accordion);
            isCorrect = style.flexDirection === 'column';
          } else if (breakpoint === 1024) {
            const productLayout = container.querySelector('.product-layout');
            const style = window.getComputedStyle(productLayout);
            isCorrect = style.flexDirection === 'column';
          } else if (breakpoint === 900) {
            const hero = container.querySelector('.hero');
            const style = window.getComputedStyle(hero);
            isCorrect = style.height === 'auto' || style.minHeight === '640px';
          } else if (breakpoint === 768) {
            const navToggle = container.querySelector('.nav-toggle');
            const nav = container.querySelector('.nav');
            const toggleStyle = window.getComputedStyle(navToggle);
            const navStyle = window.getComputedStyle(nav);
            isCorrect = toggleStyle.display === 'block' && navStyle.display === 'none';
          }

          document.head.removeChild(newStyle);
          
          return isCorrect;
        }
      ),
      { numRuns: 50 }
    );
  });

  it('should apply all responsive changes consistently across random viewport widths', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 320, max: 1920 }), // All viewport widths
        (viewportWidth) => {
          // This test verifies that multiple responsive changes happen together
          const oldStyle = document.head.querySelector('style');
          if (oldStyle) {
            document.head.removeChild(oldStyle);
          }
          
          const newStyle = document.createElement('style');
          
          // Determine which breakpoint range we're in
          const isBelow768 = viewportWidth <= 768;
          const isBelow900 = viewportWidth <= 900;
          const isBelow1024 = viewportWidth <= 1024;
          const isBelow1200 = viewportWidth <= 1200;
          const isBelow1400 = viewportWidth <= 1400;
          
          newStyle.textContent = `
            .hero__nav {
              left: ${isBelow1400 ? '32px' : '53px'};
              right: ${isBelow1400 ? '32px' : '53px'};
            }
            .accordion-section {
              flex-direction: ${isBelow1200 ? 'column' : 'row'};
            }
            .product-layout {
              flex-direction: ${isBelow1024 ? 'column' : 'row'};
            }
            .hero {
              height: ${isBelow900 ? 'auto' : '794px'};
            }
            .nav-toggle {
              display: ${isBelow768 ? 'block' : 'none'};
            }
            .nav {
              display: ${isBelow768 ? 'none' : 'flex'};
            }
          `;
          
          document.head.appendChild(newStyle);

          // Verify all elements have correct styles
          const heroNav = container.querySelector('.hero__nav');
          const accordion = container.querySelector('.accordion-section');
          const productLayout = container.querySelector('.product-layout');
          const hero = container.querySelector('.hero');
          const navToggle = container.querySelector('.nav-toggle');
          const nav = container.querySelector('.nav');

          const heroNavStyle = window.getComputedStyle(heroNav);
          const accordionStyle = window.getComputedStyle(accordion);
          const productLayoutStyle = window.getComputedStyle(productLayout);
          const heroStyle = window.getComputedStyle(hero);
          const navToggleStyle = window.getComputedStyle(navToggle);
          const navStyle = window.getComputedStyle(nav);

          const allCorrect = 
            heroNavStyle.left === (isBelow1400 ? '32px' : '53px') &&
            accordionStyle.flexDirection === (isBelow1200 ? 'column' : 'row') &&
            productLayoutStyle.flexDirection === (isBelow1024 ? 'column' : 'row') &&
            (heroStyle.height === (isBelow900 ? 'auto' : '794px') || isBelow900) &&
            navToggleStyle.display === (isBelow768 ? 'block' : 'none') &&
            navStyle.display === (isBelow768 ? 'none' : 'flex');

          document.head.removeChild(newStyle);
          
          return allCorrect;
        }
      ),
      { numRuns: 100 }
    );
  });
});
