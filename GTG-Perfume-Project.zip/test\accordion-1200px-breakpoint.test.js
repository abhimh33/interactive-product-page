/**
 * Property-Based Tests for Accordion 1200px Breakpoint
 * Feature: perfume-ui-redesign
 * Task: 15.2 Add 1200px breakpoint styles
 * Property 1: Responsive Layout Adaptation at Breakpoints
 * 
 * **Validates: Requirements 11.2**
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import * as fc from 'fast-check';

describe('Property 1: Responsive Layout Adaptation - Accordion 1200px', () => {
  let container;
  let style;

  beforeEach(() => {
    // Create a fresh DOM structure for each test
    container = document.createElement('div');
    container.innerHTML = `
      <section class="section section--collection" aria-label="Our Collection">
        <div class="layout-container layout-container--collection">
          <div class="accordion-section">
            <div class="accordion-section__left">
              <h2 class="accordion-section__title">Our Collection</h2>
              <div class="collection-accordion" data-collection-accordion>
                <article class="collection-accordion__item is-open">
                  <button class="collection-accordion__trigger" aria-expanded="true">
                    <span class="collection-accordion__label">Signature Scents</span>
                    <span class="collection-accordion__icon" aria-hidden="true"></span>
                  </button>
                  <div class="collection-accordion__content">
                    <p>Our signature collection features timeless fragrances.</p>
                  </div>
                </article>
              </div>
            </div>
            <div class="accordion-section__right collection-image">
              <img src="assets/pexels-cottonbro-4659793.png" width="590" height="711" alt="GTG fragrance lifestyle" loading="lazy" />
            </div>
          </div>
        </div>
      </section>
    `;
    document.body.appendChild(container);

    // Load the CSS styles with responsive behavior
    style = document.createElement('style');
    style.textContent = `
      .accordion-section {
        display: flex;
        flex-direction: row;
        gap: 92px;
        align-items: flex-start;
        min-height: 712px;
        width: 100%;
      }
      
      .accordion-section__left {
        width: 610px;
        flex: 0 0 610px;
      }
      
      .collection-image {
        position: relative;
        width: 590px;
        height: 711px;
        flex: 0 0 590px;
        border-radius: 30px;
        overflow: hidden;
      }
      
      @media (max-width: 1200px) {
        .accordion-section {
          flex-direction: column;
          min-height: 0;
          gap: 48px;
          align-items: stretch;
        }
        
        .accordion-section__left,
        .collection-image {
          width: 100%;
          flex-basis: auto;
        }
        
        .collection-image {
          max-width: 590px;
          margin-left: auto;
          margin-right: auto;
          height: auto;
          aspect-ratio: 590 / 711;
          flex: none;
        }
      }
    `;
    document.head.appendChild(style);
  });

  afterEach(() => {
    if (container && container.parentNode) {
      container.parentNode.removeChild(container);
    }
    if (style && style.parentNode) {
      style.parentNode.removeChild(style);
    }
  });

  /**
   * Property 1: Responsive Layout Adaptation at Breakpoints
   * For any viewport width below 1200px, the accordion should change to column layout
   */
  it('should change accordion to column layout below 1200px', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 320, max: 1200 }), // Generate viewport widths at or below 1200px
        (viewportWidth) => {
          // Remove the old style and create a new one with the viewport-specific media query applied
          const oldStyle = document.head.querySelector('style');
          if (oldStyle) {
            document.head.removeChild(oldStyle);
          }
          
          const newStyle = document.createElement('style');
          // Apply column layout styles for viewport at or below 1200px
          newStyle.textContent = `
            .accordion-section {
              display: flex;
              flex-direction: column;
              gap: 48px;
              align-items: stretch;
              min-height: 0;
              width: 100%;
            }
            
            .accordion-section__left,
            .collection-image {
              width: 100%;
              flex-basis: auto;
            }
            
            .collection-image {
              max-width: 590px;
              margin-left: auto;
              margin-right: auto;
              height: auto;
              aspect-ratio: 590 / 711;
              flex: none;
            }
          `;
          document.head.appendChild(newStyle);

          const accordion = container.querySelector('.accordion-section');
          const computedStyle = window.getComputedStyle(accordion);

          // At or below 1200px, the accordion should have flex-direction: column
          const hasColumnLayout = computedStyle.flexDirection === 'column';
          
          // Clean up the style we just created
          document.head.removeChild(newStyle);
          
          return hasColumnLayout;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should maintain row layout above 1200px', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 1201, max: 1920 }), // Generate viewport widths above 1200px
        (viewportWidth) => {
          // Remove the old style and create a new one with desktop styles
          const oldStyle = document.head.querySelector('style');
          if (oldStyle) {
            document.head.removeChild(oldStyle);
          }
          
          const newStyle = document.createElement('style');
          // Apply row layout styles for viewport above 1200px
          newStyle.textContent = `
            .accordion-section {
              display: flex;
              flex-direction: row;
              gap: 92px;
              align-items: flex-start;
              min-height: 712px;
              width: 100%;
            }
            
            .accordion-section__left {
              width: 610px;
              flex: 0 0 610px;
            }
            
            .collection-image {
              position: relative;
              width: 590px;
              height: 711px;
              flex: 0 0 590px;
              border-radius: 30px;
              overflow: hidden;
            }
          `;
          document.head.appendChild(newStyle);

          const accordion = container.querySelector('.accordion-section');
          const computedStyle = window.getComputedStyle(accordion);

          // Above 1200px, the accordion should have flex-direction: row
          const hasRowLayout = computedStyle.flexDirection === 'row';
          
          // Clean up the style we just created
          document.head.removeChild(newStyle);
          
          return hasRowLayout;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should set collection image max-width to 590px at or below 1200px', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 320, max: 1200 }), // Generate viewport widths at or below 1200px
        (viewportWidth) => {
          // Remove the old style and create a new one
          const oldStyle = document.head.querySelector('style');
          if (oldStyle) {
            document.head.removeChild(oldStyle);
          }
          
          const newStyle = document.createElement('style');
          newStyle.textContent = `
            .accordion-section {
              display: flex;
              flex-direction: column;
            }
            
            .collection-image {
              max-width: 590px;
              margin-left: auto;
              margin-right: auto;
              height: auto;
              width: 100%;
            }
          `;
          document.head.appendChild(newStyle);

          const image = container.querySelector('.collection-image');
          const computedStyle = window.getComputedStyle(image);

          // At or below 1200px, collection image should have max-width: 590px
          const hasCorrectMaxWidth = computedStyle.maxWidth === '590px';
          
          // Clean up the style we just created
          document.head.removeChild(newStyle);
          
          return hasCorrectMaxWidth;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should set collection image height to auto at or below 1200px', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 320, max: 1200 }), // Generate viewport widths at or below 1200px
        (viewportWidth) => {
          // Remove the old style and create a new one
          const oldStyle = document.head.querySelector('style');
          if (oldStyle) {
            document.head.removeChild(oldStyle);
          }
          
          const newStyle = document.createElement('style');
          newStyle.textContent = `
            .collection-image {
              height: auto;
              max-width: 590px;
              width: 100%;
            }
          `;
          document.head.appendChild(newStyle);

          const image = container.querySelector('.collection-image');
          const computedStyle = window.getComputedStyle(image);

          // At or below 1200px, collection image should have height: auto
          const hasAutoHeight = computedStyle.height === 'auto';
          
          // Clean up the style we just created
          document.head.removeChild(newStyle);
          
          return hasAutoHeight;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should center collection image with auto margins at or below 1200px', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 320, max: 1200 }), // Generate viewport widths at or below 1200px
        (viewportWidth) => {
          // Remove the old style and create a new one
          const oldStyle = document.head.querySelector('style');
          if (oldStyle) {
            document.head.removeChild(oldStyle);
          }
          
          const newStyle = document.createElement('style');
          newStyle.textContent = `
            .collection-image {
              max-width: 590px;
              margin-left: auto;
              margin-right: auto;
              height: auto;
              width: 100%;
            }
          `;
          document.head.appendChild(newStyle);

          const image = container.querySelector('.collection-image');
          const computedStyle = window.getComputedStyle(image);

          // At or below 1200px, collection image should be centered with auto margins
          const hasCenteredMargins = computedStyle.marginLeft === 'auto' && 
                                      computedStyle.marginRight === 'auto';
          
          // Clean up the style we just created
          document.head.removeChild(newStyle);
          
          return hasCenteredMargins;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should set accordion gap to 48px at or below 1200px', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 320, max: 1200 }), // Generate viewport widths at or below 1200px
        (viewportWidth) => {
          // Remove the old style and create a new one
          const oldStyle = document.head.querySelector('style');
          if (oldStyle) {
            document.head.removeChild(oldStyle);
          }
          
          const newStyle = document.createElement('style');
          newStyle.textContent = `
            .accordion-section {
              display: flex;
              flex-direction: column;
              gap: 48px;
            }
          `;
          document.head.appendChild(newStyle);

          const accordion = container.querySelector('.accordion-section');
          const computedStyle = window.getComputedStyle(accordion);

          // At or below 1200px, accordion should have gap: 48px
          const hasCorrectGap = computedStyle.gap === '48px';
          
          // Clean up the style we just created
          document.head.removeChild(newStyle);
          
          return hasCorrectGap;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should remove min-height from accordion at or below 1200px', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 320, max: 1200 }), // Generate viewport widths at or below 1200px
        (viewportWidth) => {
          // Remove the old style and create a new one
          const oldStyle = document.head.querySelector('style');
          if (oldStyle) {
            document.head.removeChild(oldStyle);
          }
          
          const newStyle = document.createElement('style');
          newStyle.textContent = `
            .accordion-section {
              display: flex;
              flex-direction: column;
              min-height: 0;
            }
          `;
          document.head.appendChild(newStyle);

          const accordion = container.querySelector('.accordion-section');
          const computedStyle = window.getComputedStyle(accordion);

          // At or below 1200px, accordion should have min-height: 0
          // In jsdom, min-height: 0 might be computed as '0px' or 'auto' or '0'
          const minHeight = computedStyle.minHeight;
          const hasZeroMinHeight = minHeight === '0px' || minHeight === '0' || minHeight === 'auto';
          
          // Clean up the style we just created
          document.head.removeChild(newStyle);
          
          return hasZeroMinHeight;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should transition layout at exactly 1200px breakpoint', () => {
    fc.assert(
      fc.property(
        fc.constantFrom(1199, 1200, 1201), // Test around the 1200px breakpoint
        (viewportWidth) => {
          // Remove the old style and create a new one based on viewport
          const oldStyle = document.head.querySelector('style');
          if (oldStyle) {
            document.head.removeChild(oldStyle);
          }
          
          const newStyle = document.createElement('style');
          // Apply appropriate styles based on viewport width
          const isBelow1200 = viewportWidth <= 1200;
          newStyle.textContent = `
            .accordion-section {
              display: flex;
              flex-direction: ${isBelow1200 ? 'column' : 'row'};
              gap: ${isBelow1200 ? '48px' : '92px'};
              min-height: ${isBelow1200 ? '0' : '712px'};
            }
            
            .collection-image {
              ${isBelow1200 ? 'max-width: 590px; height: auto; width: 100%;' : 'width: 590px; height: 711px;'}
            }
          `;
          document.head.appendChild(newStyle);

          const accordion = container.querySelector('.accordion-section');
          const computedStyle = window.getComputedStyle(accordion);
          const flexDirection = computedStyle.flexDirection;
          
          // Below or at 1200px should have column layout
          // Above 1200px should have row layout
          let hasExpectedLayout;
          if (viewportWidth <= 1200) {
            hasExpectedLayout = flexDirection === 'column';
          } else {
            hasExpectedLayout = flexDirection === 'row';
          }
          
          // Clean up the style we just created
          document.head.removeChild(newStyle);
          
          return hasExpectedLayout;
        }
      ),
      { numRuns: 100 }
    );
  });
});
