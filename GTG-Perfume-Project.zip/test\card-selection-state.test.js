/**
 * Card Selection State Property Tests
 * 
 * Feature: perfume-ui-redesign
 * Task: 8.5 Write property test for card selection state
 * Property 3: Selection State Styling Consistency
 * 
 * **Validates: Requirements 6.4**
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import * as fc from 'fast-check';

describe('Card Selection State - Property Tests', () => {
  let container;
  let style;

  beforeEach(() => {
    container = document.createElement('div');
    document.body.appendChild(container);

    // Load the CSS styles inline
    style = document.createElement('style');
    style.textContent = `
      * {
        box-sizing: border-box;
      }
      
      .product-scent {
        position: relative;
      }

      .product-scent input {
        position: absolute;
        opacity: 0;
        pointer-events: none;
      }

      .product-scent__card {
        position: relative;
        display: flex;
        flex-direction: column;
        gap: 8px;
        padding: 10px 8px 12px;
        border-radius: 10px;
        border: 1px solid #e0e0e0;
        background: #f4f4f5;
        height: 100%;
        min-height: 148px;
        box-sizing: border-box;
      }

      .product-scent input:checked + .product-scent__card {
        border-color: #064e22;
        border-width: 2px;
        padding: 9px 7px 11px;
        background: #ffffff;
      }
    `;
    document.head.appendChild(style);
  });

  afterEach(() => {
    document.body.removeChild(container);
    document.head.removeChild(style);
  });

  /**
   * Property 3: Selection State Styling Consistency
   * For any selectable card, when the card is selected, the system should apply
   * the active/selected styling (border, background, padding adjustment).
   */
  it('should apply border: 2px solid #064e22 and background: #ffffff to any selected card', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 2, max: 6 }), // Number of cards
        fc.integer({ min: 0, max: 5 }), // Index of selected card
        (numCards, selectedIndex) => {
          // Ensure selectedIndex is within bounds
          const actualSelectedIndex = selectedIndex % numCards;
          
          // Create cards dynamically
          const cards = [];
          for (let i = 0; i < numCards; i++) {
            cards.push(`
              <label class="product-scent">
                <input type="radio" name="fragrance" value="card-${i}" ${i === actualSelectedIndex ? 'checked' : ''} />
                <span class="product-scent__card">
                  <span class="product-scent__pick">Card ${i}</span>
                </span>
              </label>
            `);
          }
          
          container.innerHTML = `<div class="product-scents">${cards.join('')}</div>`;
          
          // Get the selected card
          const selectedInput = container.querySelector('input[type="radio"]:checked');
          const selectedCard = selectedInput.nextElementSibling;
          const computedStyle = window.getComputedStyle(selectedCard);
          
          // Verify border is 2px solid #064e22
          expect(computedStyle.borderWidth).toBe('2px');
          expect(['rgb(6, 78, 34)', '#064e22']).toContain(computedStyle.borderColor);
          
          // Verify background is #ffffff
          expect(['rgb(255, 255, 255)', '#ffffff', 'white']).toContain(computedStyle.backgroundColor);
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should adjust padding to 9px 7px 11px when any card is selected', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 2, max: 6 }), // Number of cards
        fc.integer({ min: 0, max: 5 }), // Index of selected card
        (numCards, selectedIndex) => {
          // Ensure selectedIndex is within bounds
          const actualSelectedIndex = selectedIndex % numCards;
          
          // Create cards dynamically
          const cards = [];
          for (let i = 0; i < numCards; i++) {
            cards.push(`
              <label class="product-scent">
                <input type="radio" name="fragrance" value="card-${i}" ${i === actualSelectedIndex ? 'checked' : ''} />
                <span class="product-scent__card">
                  <span class="product-scent__pick">Card ${i}</span>
                </span>
              </label>
            `);
          }
          
          container.innerHTML = `<div class="product-scents">${cards.join('')}</div>`;
          
          // Get the selected card
          const selectedInput = container.querySelector('input[type="radio"]:checked');
          const selectedCard = selectedInput.nextElementSibling;
          const computedStyle = window.getComputedStyle(selectedCard);
          
          // Verify padding is adjusted to 9px 7px 11px (to account for thicker border)
          expect(computedStyle.paddingTop).toBe('9px');
          expect(computedStyle.paddingRight).toBe('7px');
          expect(computedStyle.paddingBottom).toBe('11px');
          expect(computedStyle.paddingLeft).toBe('7px');
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should maintain unselected card styling (1px border, #f4f4f5 background, 10px 8px 12px padding) for all non-selected cards', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 3, max: 6 }), // Number of cards (at least 3 to have unselected cards)
        fc.integer({ min: 0, max: 5 }), // Index of selected card
        (numCards, selectedIndex) => {
          // Ensure selectedIndex is within bounds
          const actualSelectedIndex = selectedIndex % numCards;
          
          // Create cards dynamically
          const cards = [];
          for (let i = 0; i < numCards; i++) {
            cards.push(`
              <label class="product-scent">
                <input type="radio" name="fragrance" value="card-${i}" ${i === actualSelectedIndex ? 'checked' : ''} />
                <span class="product-scent__card">
                  <span class="product-scent__pick">Card ${i}</span>
                </span>
              </label>
            `);
          }
          
          container.innerHTML = `<div class="product-scents">${cards.join('')}</div>`;
          
          // Get all unselected cards
          const unselectedInputs = container.querySelectorAll('input[type="radio"]:not(:checked)');
          
          // Verify each unselected card maintains default styling
          unselectedInputs.forEach(input => {
            const card = input.nextElementSibling;
            const computedStyle = window.getComputedStyle(card);
            
            // Verify border is 1px solid #e0e0e0
            expect(computedStyle.borderWidth).toBe('1px');
            expect(['rgb(224, 224, 224)', '#e0e0e0']).toContain(computedStyle.borderColor);
            
            // Verify background is #f4f4f5
            expect(['rgb(244, 244, 245)', '#f4f4f5']).toContain(computedStyle.backgroundColor);
            
            // Verify padding is 10px 8px 12px
            expect(computedStyle.paddingTop).toBe('10px');
            expect(computedStyle.paddingRight).toBe('8px');
            expect(computedStyle.paddingBottom).toBe('12px');
            expect(computedStyle.paddingLeft).toBe('8px');
          });
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should apply selection styling consistently regardless of card position in the grid', () => {
    fc.assert(
      fc.property(
        fc.constantFrom(3, 4, 5, 6), // Number of cards (typical grid sizes)
        fc.integer({ min: 0, max: 5 }), // Index of selected card
        (numCards, selectedIndex) => {
          // Ensure selectedIndex is within bounds
          const actualSelectedIndex = selectedIndex % numCards;
          
          // Create cards dynamically with varied content
          const cards = [];
          for (let i = 0; i < numCards; i++) {
            const hasBadge = i % 2 === 0; // Some cards have badges
            cards.push(`
              <label class="product-scent">
                <input type="radio" name="fragrance" value="card-${i}" ${i === actualSelectedIndex ? 'checked' : ''} />
                <span class="product-scent__card">
                  ${hasBadge ? '<span class="product-scent__badge">BEST-SELLER</span>' : ''}
                  <span class="product-scent__pick">Card ${i}</span>
                  <span class="product-scent__img-wrap">
                    <img src="test.png" alt="" />
                  </span>
                </span>
              </label>
            `);
          }
          
          container.innerHTML = `<div class="product-scents">${cards.join('')}</div>`;
          
          // Get the selected card
          const selectedInput = container.querySelector('input[type="radio"]:checked');
          const selectedCard = selectedInput.nextElementSibling;
          const computedStyle = window.getComputedStyle(selectedCard);
          
          // Verify selection styling is applied regardless of position or content
          expect(computedStyle.borderWidth).toBe('2px');
          expect(['rgb(6, 78, 34)', '#064e22']).toContain(computedStyle.borderColor);
          expect(['rgb(255, 255, 255)', '#ffffff', 'white']).toContain(computedStyle.backgroundColor);
          expect(computedStyle.paddingTop).toBe('9px');
          expect(computedStyle.paddingRight).toBe('7px');
          expect(computedStyle.paddingBottom).toBe('11px');
          expect(computedStyle.paddingLeft).toBe('7px');
        }
      ),
      { numRuns: 100 }
    );
  });
});
