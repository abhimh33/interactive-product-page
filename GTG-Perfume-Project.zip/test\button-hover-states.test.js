/**
 * Button Hover States Tests
 * 
 * Feature: perfume-ui-redesign
 * Task: 16.1 Add button hover states
 * 
 * **Validates: Requirements 12.1**
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';

describe('Button Hover States', () => {
  let container;
  let style;

  beforeEach(() => {
    container = document.createElement('div');
    container.innerHTML = `
      <nav class="hero__nav">
        <a href="#" class="btn btn--nav">Shop Now</a>
      </nav>
      <div class="hero__content">
        <a href="#" class="btn btn--hero">Get Started</a>
      </div>
      <div class="product-panel">
        <a href="#" class="product-panel__cta">Add to Cart</a>
      </div>
      <div class="compare__cta-wrap">
        <a href="#" class="btn btn--compare">Shop Now</a>
      </div>
      <footer class="footer">
        <button type="submit" class="footer__submit">Subscribe</button>
      </footer>
    `;
    document.body.appendChild(container);

    // Load the CSS styles inline
    style = document.createElement('style');
    style.textContent = `
      .btn--nav {
        min-width: 150px;
        height: 44px;
        padding: 0 22px;
        border-radius: 100px;
        font-size: 16px;
        font-weight: 500;
        line-height: 20px;
        color: #ffffff;
        background: #064e22;
      }

      .btn--nav:hover {
        filter: brightness(1.05);
      }

      .btn--hero {
        width: 185px;
        height: 48px;
        padding: 12px 16px;
        margin-top: 0;
        border-radius: 100px;
        font-size: 18px;
        font-weight: 500;
        line-height: 24px;
        color: #ffffff;
        background: linear-gradient(180deg, #032E15 0%, #016630 100%);
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
      }

      .btn--hero:hover {
        filter: brightness(1.05);
      }

      .product-panel__cta {
        width: 100%;
        height: 52px;
        border-radius: 100px;
        background: #064e22;
        color: #ffffff;
        font-size: 17px;
        font-weight: 700;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        margin-top: 8px;
      }

      .product-panel__cta:hover {
        filter: brightness(1.05);
      }

      .btn--compare {
        min-width: 280px;
        height: 60px;
        padding: 0 40px;
        border-radius: 40px;
        font-size: 18px;
        font-weight: 700;
        line-height: 24px;
        color: #ffffff;
        background: #064e22;
      }

      .btn--compare:hover {
        filter: brightness(1.05);
      }

      .footer__submit {
        height: 48px;
        padding: 0 24px;
        border: 0;
        border-radius: 0 6px 6px 0;
        background: #7a4011;
        color: #ffffff;
        font-size: 15px;
        font-weight: 600;
        font-family: inherit;
        cursor: pointer;
      }

      .footer__submit:hover {
        filter: brightness(1.05);
      }
    `;
    document.head.appendChild(style);
  });

  afterEach(() => {
    document.body.removeChild(container);
    document.head.removeChild(style);
  });

  it('should apply brightness(1.05) filter to nav button on hover', () => {
    const button = container.querySelector('.btn--nav');
    
    // Create a temporary style element to simulate hover
    const hoverStyle = document.createElement('style');
    hoverStyle.textContent = `.btn--nav { filter: brightness(1.05); }`;
    document.head.appendChild(hoverStyle);
    
    const computedStyle = window.getComputedStyle(button);
    expect(computedStyle.filter).toBe('brightness(1.05)');
    
    document.head.removeChild(hoverStyle);
  });

  it('should apply brightness(1.05) filter to hero CTA button on hover', () => {
    const button = container.querySelector('.btn--hero');
    
    // Create a temporary style element to simulate hover
    const hoverStyle = document.createElement('style');
    hoverStyle.textContent = `.btn--hero { filter: brightness(1.05); }`;
    document.head.appendChild(hoverStyle);
    
    const computedStyle = window.getComputedStyle(button);
    expect(computedStyle.filter).toBe('brightness(1.05)');
    
    document.head.removeChild(hoverStyle);
  });

  it('should apply brightness(1.05) filter to product panel CTA button on hover', () => {
    const button = container.querySelector('.product-panel__cta');
    
    // Create a temporary style element to simulate hover
    const hoverStyle = document.createElement('style');
    hoverStyle.textContent = `.product-panel__cta { filter: brightness(1.05); }`;
    document.head.appendChild(hoverStyle);
    
    const computedStyle = window.getComputedStyle(button);
    expect(computedStyle.filter).toBe('brightness(1.05)');
    
    document.head.removeChild(hoverStyle);
  });

  it('should apply brightness(1.05) filter to compare CTA button on hover', () => {
    const button = container.querySelector('.btn--compare');
    
    // Create a temporary style element to simulate hover
    const hoverStyle = document.createElement('style');
    hoverStyle.textContent = `.btn--compare { filter: brightness(1.05); }`;
    document.head.appendChild(hoverStyle);
    
    const computedStyle = window.getComputedStyle(button);
    expect(computedStyle.filter).toBe('brightness(1.05)');
    
    document.head.removeChild(hoverStyle);
  });

  it('should apply brightness(1.05) filter to footer submit button on hover', () => {
    const button = container.querySelector('.footer__submit');
    
    // Create a temporary style element to simulate hover
    const hoverStyle = document.createElement('style');
    hoverStyle.textContent = `.footer__submit { filter: brightness(1.05); }`;
    document.head.appendChild(hoverStyle);
    
    const computedStyle = window.getComputedStyle(button);
    expect(computedStyle.filter).toBe('brightness(1.05)');
    
    document.head.removeChild(hoverStyle);
  });

  it('should have hover styles defined in CSS for all button types', () => {
    // Verify that the hover styles are present in the stylesheet
    const buttons = [
      '.btn--nav',
      '.btn--hero',
      '.product-panel__cta',
      '.btn--compare',
      '.footer__submit'
    ];

    buttons.forEach(selector => {
      const button = container.querySelector(selector);
      expect(button).toBeTruthy();
    });
  });
});
