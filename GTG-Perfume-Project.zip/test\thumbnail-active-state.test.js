/**
 * Property-Based Tests for Thumbnail Active State
 * Feature: perfume-ui-redesign
 * Property 3: Selection State Styling Consistency
 * 
 * **Validates: Requirements 3.7**
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import * as fc from 'fast-check';

describe('Property 3: Selection State Styling Consistency - Thumbnail Active State', () => {
  let container;
  let style;

  beforeEach(() => {
    // Create a fresh DOM structure for each test
    container = document.createElement('div');
    container.innerHTML = `
      <div class="product-gallery">
        <div class="product-carousel">
          <div class="product-carousel__frame">
            <div class="product-carousel__viewport">
              <img data-gallery-image class="product-carousel__img" src="assets/image1.png" alt="Product image" />
            </div>
          </div>
        </div>
        <div class="product-thumbs" data-gallery-thumbs>
          <button type="button" class="product-thumb is-active" data-thumb-index="0">
            <img src="assets/thumb1.png" alt="" />
          </button>
          <button type="button" class="product-thumb" data-thumb-index="1">
            <img src="assets/thumb2.png" alt="" />
          </button>
          <button type="button" class="product-thumb" data-thumb-index="2">
            <img src="assets/thumb3.png" alt="" />
          </button>
          <button type="button" class="product-thumb" data-thumb-index="3">
            <img src="assets/thumb4.png" alt="" />
          </button>
          <button type="button" class="product-thumb" data-thumb-index="4">
            <img src="assets/thumb5.png" alt="" />
          </button>
          <button type="button" class="product-thumb" data-thumb-index="5">
            <img src="assets/thumb6.png" alt="" />
          </button>
          <button type="button" class="product-thumb" data-thumb-index="6">
            <img src="assets/thumb7.png" alt="" />
          </button>
          <button type="button" class="product-thumb" data-thumb-index="7">
            <img src="assets/thumb8.png" alt="" />
          </button>
        </div>
      </div>
    `;
    document.body.appendChild(container);

    // Load the CSS styles
    style = document.createElement('style');
    style.textContent = `
      .product-thumbs {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        gap: 14px;
      }
      
      .product-thumbs .product-thumb {
        aspect-ratio: 1 / 1;
        padding: 0;
        border: 2px solid transparent;
        border-radius: 14px;
        overflow: hidden;
        cursor: pointer;
        background: #f1f5f9;
      }
      
      .product-thumbs .product-thumb.is-active {
        border-color: #064e22;
      }
    `;
    document.head.appendChild(style);
  });

  afterEach(() => {
    if (container && container.parentNode) {
      container.parentNode.removeChild(container);
    }
    if (style && style.parentNode) {
      style.parentNode.removeChild(style);
    }
  });

  it('should apply border: 2px solid #064e22 when any thumbnail is clicked', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 0, max: 7 }), // Generate random thumbnail indices (0-7)
        (thumbnailIndex) => {
          // Get all thumbnails
          const thumbnails = container.querySelectorAll('.product-thumb');
          
          // Clear all active states first
          thumbnails.forEach(thumb => thumb.classList.remove('is-active'));
          
          // Click the selected thumbnail
          const selectedThumb = thumbnails[thumbnailIndex];
          selectedThumb.classList.add('is-active');
          
          // Get computed style
          const computedStyle = window.getComputedStyle(selectedThumb);
          
          // Check that the border is applied correctly
          const borderWidth = computedStyle.borderWidth;
          const borderStyle = computedStyle.borderStyle;
          const borderColor = computedStyle.borderColor;
          
          // Verify border width is 2px
          const hasTwoPixelBorder = borderWidth === '2px';
          
          // Verify border style is solid
          const hasSolidBorder = borderStyle === 'solid';
          
          // Verify border color is #064e22 (rgb(6, 78, 34))
          const hasCorrectColor = borderColor === 'rgb(6, 78, 34)' || borderColor === '#064e22';
          
          return hasTwoPixelBorder && hasSolidBorder && hasCorrectColor;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should ensure only one thumbnail has active state at a time', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 0, max: 7 }), // Generate random thumbnail indices (0-7)
        (thumbnailIndex) => {
          // Get all thumbnails
          const thumbnails = container.querySelectorAll('.product-thumb');
          
          // Clear all active states first
          thumbnails.forEach(thumb => thumb.classList.remove('is-active'));
          
          // Activate the selected thumbnail
          thumbnails[thumbnailIndex].classList.add('is-active');
          
          // Count how many thumbnails have the is-active class
          const activeCount = Array.from(thumbnails).filter(thumb => 
            thumb.classList.contains('is-active')
          ).length;
          
          // Verify exactly one thumbnail is active
          return activeCount === 1;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should maintain active state exclusivity when clicking different thumbnails sequentially', () => {
    fc.assert(
      fc.property(
        fc.array(fc.integer({ min: 0, max: 7 }), { minLength: 2, maxLength: 5 }), // Generate sequence of clicks
        (clickSequence) => {
          const thumbnails = container.querySelectorAll('.product-thumb');
          
          // Simulate clicking thumbnails in sequence
          for (const index of clickSequence) {
            // Remove active from all
            thumbnails.forEach(thumb => thumb.classList.remove('is-active'));
            // Add active to clicked one
            thumbnails[index].classList.add('is-active');
            
            // Verify only one is active after each click
            const activeCount = Array.from(thumbnails).filter(thumb => 
              thumb.classList.contains('is-active')
            ).length;
            
            if (activeCount !== 1) {
              return false;
            }
          }
          
          return true;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should apply correct border styling to active thumbnail regardless of previous state', () => {
    fc.assert(
      fc.property(
        fc.tuple(
          fc.integer({ min: 0, max: 7 }), // First thumbnail to activate
          fc.integer({ min: 0, max: 7 })  // Second thumbnail to activate
        ).filter(([first, second]) => first !== second), // Ensure different thumbnails
        ([firstIndex, secondIndex]) => {
          const thumbnails = container.querySelectorAll('.product-thumb');
          
          // Clear all active states
          thumbnails.forEach(thumb => thumb.classList.remove('is-active'));
          
          // Activate first thumbnail
          thumbnails[firstIndex].classList.add('is-active');
          
          // Deactivate first and activate second
          thumbnails[firstIndex].classList.remove('is-active');
          thumbnails[secondIndex].classList.add('is-active');
          
          // Check that first thumbnail no longer has active border
          const firstStyle = window.getComputedStyle(thumbnails[firstIndex]);
          const firstBorderColor = firstStyle.borderColor;
          const firstIsTransparent = firstBorderColor === 'rgba(0, 0, 0, 0)' || 
                                     firstBorderColor === 'transparent';
          
          // Check that second thumbnail has active border
          const secondStyle = window.getComputedStyle(thumbnails[secondIndex]);
          const secondBorderColor = secondStyle.borderColor;
          const secondHasActiveColor = secondBorderColor === 'rgb(6, 78, 34)' || 
                                       secondBorderColor === '#064e22';
          
          return firstIsTransparent && secondHasActiveColor;
        }
      ),
      { numRuns: 100 }
    );
  });
});
