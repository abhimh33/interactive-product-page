/**
 * Property-Based Tests for Responsive Navigation
 * Feature: perfume-ui-redesign
 * Property 1: Responsive Layout Adaptation at Breakpoints
 * 
 * **Validates: Requirements 2.6, 11.5**
 */

import { describe, it, expect, beforeEach } from 'vitest';
import * as fc from 'fast-check';

describe('Property 1: Responsive Layout Adaptation at Breakpoints', () => {
  let container;

  beforeEach(() => {
    // Create a fresh DOM structure for each test
    container = document.createElement('div');
    container.innerHTML = `
      <header class="hero__nav">
        <div class="nav__left">
          <a class="logo" href="#">GTG</a>
        </div>
        <button class="nav-toggle" type="button" aria-expanded="false">
          <span class="sr-only">Toggle navigation</span>
          <span class="nav-toggle__bar"></span>
          <span class="nav-toggle__bar"></span>
          <span class="nav-toggle__bar"></span>
        </button>
        <nav id="primary-nav" class="nav" data-nav>
          <ul class="nav__list">
            <li><a href="#">Home</a></li>
            <li><a href="#">Shop</a></li>
            <li><a href="#">Fragrances</a></li>
            <li><a href="#">About Us</a></li>
            <li><a href="#">Blog</a></li>
            <li><a href="#">Contact</a></li>
          </ul>
        </nav>
        <div class="nav__right">
          <button class="icon-button" type="button" aria-label="Search">
            <svg viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27a6.5 6.5 0 1 0-.71.71l.27.28v.79l5 5 1.5-1.5-5-5z" /></svg>
          </button>
          <a class="btn btn--nav" href="#">Shop Now</a>
        </div>
      </header>
    `;
    document.body.appendChild(container);

    // Load the CSS styles
    const style = document.createElement('style');
    style.textContent = `
      .nav-toggle {
        display: none;
      }
      
      .nav {
        display: flex;
      }
      
      @media (max-width: 768px) {
        .nav-toggle {
          display: block;
        }
        
        .nav {
          display: none;
        }
        
        .nav.is-open {
          display: flex;
        }
      }
    `;
    document.head.appendChild(style);
  });

  it('should display mobile navigation toggle below 768px', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 320, max: 767 }), // Generate viewport widths below 768px
        (viewportWidth) => {
          // Set viewport width
          Object.defineProperty(window, 'innerWidth', {
            writable: true,
            configurable: true,
            value: viewportWidth,
          });

          // Trigger matchMedia for the breakpoint
          const mediaQuery = window.matchMedia('(max-width: 768px)');
          Object.defineProperty(mediaQuery, 'matches', {
            writable: true,
            configurable: true,
            value: viewportWidth <= 768,
          });

          const navToggle = container.querySelector('.nav-toggle');
          const computedStyle = window.getComputedStyle(navToggle);

          // At mobile widths, the toggle should be visible (display: block)
          // We check that it's not 'none'
          const isToggleVisible = computedStyle.display !== 'none';

          return isToggleVisible;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should hide desktop navigation below 768px', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 320, max: 767 }), // Generate viewport widths below 768px
        (viewportWidth) => {
          // Set viewport width
          Object.defineProperty(window, 'innerWidth', {
            writable: true,
            configurable: true,
            value: viewportWidth,
          });

          // Trigger matchMedia for the breakpoint
          const mediaQuery = window.matchMedia('(max-width: 768px)');
          Object.defineProperty(mediaQuery, 'matches', {
            writable: true,
            configurable: true,
            value: viewportWidth <= 768,
          });

          const nav = container.querySelector('.nav');
          const computedStyle = window.getComputedStyle(nav);

          // At mobile widths, the nav should be hidden (display: none) unless .is-open
          const isNavHidden = computedStyle.display === 'none' || nav.classList.contains('is-open');

          return isNavHidden;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should display desktop navigation at 768px and above', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 768, max: 1920 }), // Generate viewport widths at or above 768px
        (viewportWidth) => {
          // Set viewport width
          Object.defineProperty(window, 'innerWidth', {
            writable: true,
            configurable: true,
            value: viewportWidth,
          });

          // Trigger matchMedia for the breakpoint
          const mediaQuery = window.matchMedia('(max-width: 768px)');
          Object.defineProperty(mediaQuery, 'matches', {
            writable: true,
            configurable: true,
            value: viewportWidth <= 768,
          });

          const nav = container.querySelector('.nav');
          const computedStyle = window.getComputedStyle(nav);

          // At desktop widths, the nav should be visible (display: flex)
          const isNavVisible = computedStyle.display === 'flex';

          return isNavVisible;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should hide mobile navigation toggle at 768px and above', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 768, max: 1920 }), // Generate viewport widths at or above 768px
        (viewportWidth) => {
          // Set viewport width
          Object.defineProperty(window, 'innerWidth', {
            writable: true,
            configurable: true,
            value: viewportWidth,
          });

          // Trigger matchMedia for the breakpoint
          const mediaQuery = window.matchMedia('(max-width: 768px)');
          Object.defineProperty(mediaQuery, 'matches', {
            writable: true,
            configurable: true,
            value: viewportWidth <= 768,
          });

          const navToggle = container.querySelector('.nav-toggle');
          const computedStyle = window.getComputedStyle(navToggle);

          // At desktop widths, the toggle should be hidden (display: none)
          const isToggleHidden = computedStyle.display === 'none';

          return isToggleHidden;
        }
      ),
      { numRuns: 100 }
    );
  });
});
