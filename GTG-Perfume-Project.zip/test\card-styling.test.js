/**
 * Card Styling Tests
 * 
 * Feature: perfume-ui-redesign
 * Task: 8.2 Update card styling
 * 
 * **Validates: Requirements 6.2, 6.3, 15.5**
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';

describe('Card Styling', () => {
  let container;
  let style;

  beforeEach(() => {
    container = document.createElement('div');
    container.innerHTML = `
      <div class="product-scents">
        <label class="product-scent">
          <input type="radio" name="fragrance" value="original" />
          <span class="product-scent__card">
            <span class="product-scent__badge">BEST-SELLER</span>
            <span class="product-scent__pick">
              <span class="product-scent__dot"></span> Original
            </span>
            <span class="product-scent__img-wrap">
              <img src="test.png" alt="" class="product-scent__img" />
            </span>
          </span>
        </label>
        <label class="product-scent">
          <input type="radio" name="fragrance" value="lily" checked />
          <span class="product-scent__card">
            <span class="product-scent__pick">
              <span class="product-scent__dot"></span> Lily
            </span>
            <span class="product-scent__img-wrap">
              <img src="test.png" alt="" class="product-scent__img" />
            </span>
          </span>
        </label>
      </div>
    `;
    document.body.appendChild(container);

    // Load the CSS styles inline
    style = document.createElement('style');
    style.textContent = `
      * {
        box-sizing: border-box;
      }
      
      .product-scent {
        position: relative;
      }

      .product-scent input {
        position: absolute;
        opacity: 0;
        pointer-events: none;
      }

      .product-scent__card {
        position: relative;
        display: flex;
        flex-direction: column;
        gap: 8px;
        padding: 10px 8px 12px;
        border-radius: 10px;
        border: 1px solid #e0e0e0;
        background: #f4f4f5;
        height: 100%;
        min-height: 148px;
        box-sizing: border-box;
      }

      .product-scent input:checked + .product-scent__card {
        border-color: #064e22;
        border-width: 2px;
        padding: 9px 7px 11px;
        background: #ffffff;
      }
    `;
    document.head.appendChild(style);
  });

  afterEach(() => {
    document.body.removeChild(container);
    document.head.removeChild(style);
  });

  it('should set border-radius to 10px', () => {
    const card = container.querySelector('.product-scent__card');
    const computedStyle = window.getComputedStyle(card);
    
    expect(computedStyle.borderRadius).toBe('10px');
  });

  it('should set padding to 10px 8px 12px', () => {
    const card = container.querySelector('.product-scent__card');
    const computedStyle = window.getComputedStyle(card);
    
    expect(computedStyle.paddingTop).toBe('10px');
    expect(computedStyle.paddingRight).toBe('8px');
    expect(computedStyle.paddingBottom).toBe('12px');
    expect(computedStyle.paddingLeft).toBe('8px');
  });

  it('should set min-height to 148px', () => {
    const card = container.querySelector('.product-scent__card');
    const computedStyle = window.getComputedStyle(card);
    
    expect(computedStyle.minHeight).toBe('148px');
  });

  it('should set border to 1px solid #e0e0e0', () => {
    const card = container.querySelector('.product-scent__card');
    const computedStyle = window.getComputedStyle(card);
    
    expect(computedStyle.borderWidth).toBe('1px');
    expect(computedStyle.borderStyle).toBe('solid');
    // Browser may return color in different formats (rgb or hex)
    expect(['rgb(224, 224, 224)', '#e0e0e0']).toContain(computedStyle.borderColor);
  });

  it('should set background to #f4f4f5', () => {
    const card = container.querySelector('.product-scent__card');
    const computedStyle = window.getComputedStyle(card);
    
    // Browser may return color in different formats (rgb or hex)
    expect(['rgb(244, 244, 245)', '#f4f4f5']).toContain(computedStyle.backgroundColor);
  });

  it('should apply gap of 8px between card elements', () => {
    const card = container.querySelector('.product-scent__card');
    const computedStyle = window.getComputedStyle(card);
    
    expect(computedStyle.gap).toBe('8px');
  });

  it('should use flex-direction: column for vertical layout', () => {
    const card = container.querySelector('.product-scent__card');
    const computedStyle = window.getComputedStyle(card);
    
    expect(computedStyle.display).toBe('flex');
    expect(computedStyle.flexDirection).toBe('column');
  });

  it('should use box-sizing: border-box for accurate dimensions', () => {
    const card = container.querySelector('.product-scent__card');
    const computedStyle = window.getComputedStyle(card);
    
    expect(computedStyle.boxSizing).toBe('border-box');
  });

  it('should maintain consistent styling across multiple cards', () => {
    const allCards = container.querySelectorAll('.product-scent__card');
    
    allCards.forEach(card => {
      const computedStyle = window.getComputedStyle(card);
      
      expect(computedStyle.borderRadius).toBe('10px');
      expect(computedStyle.minHeight).toBe('148px');
      expect(computedStyle.gap).toBe('8px');
      expect(computedStyle.display).toBe('flex');
      expect(computedStyle.flexDirection).toBe('column');
    });
  });

  it('should adjust padding when card is selected (checked state)', () => {
    const checkedInput = container.querySelector('input[type="radio"]:checked');
    const selectedCard = checkedInput.nextElementSibling;
    const computedStyle = window.getComputedStyle(selectedCard);
    
    // When selected, padding should be adjusted to 9px 7px 11px to account for thicker border
    expect(computedStyle.paddingTop).toBe('9px');
    expect(computedStyle.paddingRight).toBe('7px');
    expect(computedStyle.paddingBottom).toBe('11px');
    expect(computedStyle.paddingLeft).toBe('7px');
  });

  it('should change border to 2px solid #064e22 when selected', () => {
    const checkedInput = container.querySelector('input[type="radio"]:checked');
    const selectedCard = checkedInput.nextElementSibling;
    const computedStyle = window.getComputedStyle(selectedCard);
    
    expect(computedStyle.borderWidth).toBe('2px');
    expect(['rgb(6, 78, 34)', '#064e22']).toContain(computedStyle.borderColor);
  });

  it('should change background to #ffffff when selected', () => {
    const checkedInput = container.querySelector('input[type="radio"]:checked');
    const selectedCard = checkedInput.nextElementSibling;
    const computedStyle = window.getComputedStyle(selectedCard);
    
    expect(['rgb(255, 255, 255)', '#ffffff', 'white']).toContain(computedStyle.backgroundColor);
  });
});
