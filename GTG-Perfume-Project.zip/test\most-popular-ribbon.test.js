/**
 * Most Popular Ribbon Styling Tests
 * Feature: perfume-ui-redesign
 * Task: 7.2 Update "Most Popular" ribbon
 * 
 * **Validates: Requirements 5.2**
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';

describe('Most Popular Ribbon', () => {
  let container;
  let style;

  beforeEach(() => {
    // Create a fresh DOM structure for each test
    container = document.createElement('div');
    container.innerHTML = `
      <div class="product-sub product-sub--featured">
        <div class="product-sub__ribbon">Most Popular</div>
        <div class="product-sub__row">Subscription content</div>
      </div>
    `;
    document.body.appendChild(container);

    // Load the CSS styles
    style = document.createElement('style');
    style.textContent = `
      .product-sub__ribbon {
        background: #064e22;
        color: #ffffff;
        text-align: center;
        font-size: 12px;
        font-weight: 700;
        letter-spacing: 0.06em;
        text-transform: uppercase;
        padding: 10px 12px;
      }
    `;
    document.head.appendChild(style);
  });

  afterEach(() => {
    if (container && container.parentNode) {
      container.parentNode.removeChild(container);
    }
    if (style && style.parentNode) {
      style.parentNode.removeChild(style);
    }
  });

  it('should have correct background color #064e22', () => {
    const ribbon = container.querySelector('.product-sub__ribbon');
    const computedStyle = window.getComputedStyle(ribbon);
    
    // happy-dom returns colors in hex format
    expect(computedStyle.backgroundColor).toBe('#064e22');
  });

  it('should have correct text color #ffffff', () => {
    const ribbon = container.querySelector('.product-sub__ribbon');
    const computedStyle = window.getComputedStyle(ribbon);
    
    // happy-dom returns colors in hex format
    expect(computedStyle.color).toBe('#ffffff');
  });

  it('should have font-size: 12px', () => {
    const ribbon = container.querySelector('.product-sub__ribbon');
    const computedStyle = window.getComputedStyle(ribbon);
    
    expect(computedStyle.fontSize).toBe('12px');
  });

  it('should have font-weight: 700', () => {
    const ribbon = container.querySelector('.product-sub__ribbon');
    const computedStyle = window.getComputedStyle(ribbon);
    
    expect(computedStyle.fontWeight).toBe('700');
  });

  it('should have text-transform: uppercase', () => {
    const ribbon = container.querySelector('.product-sub__ribbon');
    const computedStyle = window.getComputedStyle(ribbon);
    
    expect(computedStyle.textTransform).toBe('uppercase');
  });

  it('should have letter-spacing: 0.06em', () => {
    const ribbon = container.querySelector('.product-sub__ribbon');
    const computedStyle = window.getComputedStyle(ribbon);
    
    // 0.06em * 16px (default font size) = 0.96px
    // Note: letter-spacing is computed based on the parent's font-size in happy-dom
    expect(computedStyle.letterSpacing).toBe('0.96px');
  });

  it('should have padding: 10px 12px', () => {
    const ribbon = container.querySelector('.product-sub__ribbon');
    const computedStyle = window.getComputedStyle(ribbon);
    
    expect(computedStyle.padding).toBe('10px 12px');
  });

  it('should display "Most Popular" text', () => {
    const ribbon = container.querySelector('.product-sub__ribbon');
    
    expect(ribbon.textContent).toBe('Most Popular');
  });
});
