/**
 * Property-Based Tests for Accordion Interaction
 * Feature: perfume-ui-redesign
 * Property 2: Interactive State Visual Feedback
 * 
 * **Validates: Requirements 12.5**
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import * as fc from 'fast-check';

describe('Property 2: Interactive State Visual Feedback - Accordion Interaction', () => {
  let container;
  let style;

  beforeEach(() => {
    // Create a fresh DOM structure for each test
    container = document.createElement('div');
    container.innerHTML = `
      <section class="section section--collection">
        <div class="accordion-section">
          <div class="accordion-section__left">
            <h2 class="accordion-section__title">Our Collection</h2>
            <div class="collection-accordion" data-collection-accordion>
              <article class="collection-accordion__item is-open">
                <button class="collection-accordion__trigger" type="button" aria-expanded="true">
                  <span class="collection-accordion__label">Signature Scents</span>
                  <span class="collection-accordion__icon" aria-hidden="true"></span>
                </button>
                <div class="collection-accordion__content" data-accordion-content>
                  <p>Discover our curated line of signature perfumes.</p>
                </div>
              </article>
              <article class="collection-accordion__item">
                <button class="collection-accordion__trigger" type="button" aria-expanded="false">
                  <span class="collection-accordion__label">Botanical Series</span>
                  <span class="collection-accordion__icon" aria-hidden="true"></span>
                </button>
                <div class="collection-accordion__content" data-accordion-content>
                  <p>A nature-forward collection with green, floral profiles.</p>
                </div>
              </article>
              <article class="collection-accordion__item">
                <button class="collection-accordion__trigger" type="button" aria-expanded="false">
                  <span class="collection-accordion__label">Evening Reserve</span>
                  <span class="collection-accordion__icon" aria-hidden="true"></span>
                </button>
                <div class="collection-accordion__content" data-accordion-content>
                  <p>Rich profiles designed for after-dark wear.</p>
                </div>
              </article>
              <article class="collection-accordion__item">
                <button class="collection-accordion__trigger" type="button" aria-expanded="false">
                  <span class="collection-accordion__label">Limited Editions</span>
                  <span class="collection-accordion__icon" aria-hidden="true"></span>
                </button>
                <div class="collection-accordion__content" data-accordion-content>
                  <p>Seasonal drops and small-batch formulas.</p>
                </div>
              </article>
            </div>
          </div>
        </div>
      </section>
    `;
    document.body.appendChild(container);

    // Load the CSS styles
    style = document.createElement('style');
    style.textContent = `
      .collection-accordion__item {
        width: 100%;
        border: 1px solid #e5e7eb;
        border-radius: 14px;
        background: #ffffff;
        overflow: hidden;
      }
      
      .collection-accordion__trigger {
        width: 100%;
        border: 0;
        background: transparent;
        padding: 24px;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
        cursor: pointer;
        text-align: left;
      }
      
      .collection-accordion__label {
        font-size: 20px;
        line-height: 24px;
        font-weight: 700;
      }
      
      .collection-accordion__content {
        max-height: 0;
        opacity: 0;
        overflow: hidden;
        padding: 0 24px;
        transition: max-height 320ms ease, opacity 220ms ease, padding-bottom 220ms ease;
      }
      
      .collection-accordion__item.is-open .collection-accordion__content {
        opacity: 1;
        padding-bottom: 24px;
      }
    `;
    document.head.appendChild(style);
  });

  afterEach(() => {
    if (container && container.parentNode) {
      container.parentNode.removeChild(container);
    }
    if (style && style.parentNode) {
      style.parentNode.removeChild(style);
    }
  });

  it('should toggle is-open class when any accordion trigger is clicked', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 0, max: 3 }), // Generate random accordion item indices (0-3)
        (itemIndex) => {
          // Get all accordion items
          const items = container.querySelectorAll('.collection-accordion__item');
          const selectedItem = items[itemIndex];
          const trigger = selectedItem.querySelector('.collection-accordion__trigger');
          
          // Get initial state
          const wasOpen = selectedItem.classList.contains('is-open');
          
          // Simulate accordion behavior: toggle the clicked item
          if (wasOpen) {
            selectedItem.classList.remove('is-open');
          } else {
            selectedItem.classList.add('is-open');
          }
          
          // Check that the state toggled
          const isNowOpen = selectedItem.classList.contains('is-open');
          
          return wasOpen !== isNowOpen;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should update aria-expanded attribute correctly when accordion trigger is clicked', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 0, max: 3 }), // Generate random accordion item indices (0-3)
        (itemIndex) => {
          // Get all accordion items
          const items = container.querySelectorAll('.collection-accordion__item');
          const selectedItem = items[itemIndex];
          const trigger = selectedItem.querySelector('.collection-accordion__trigger');
          
          // Get initial aria-expanded value
          const initialAriaExpanded = trigger.getAttribute('aria-expanded');
          
          // Simulate accordion behavior: toggle aria-expanded
          const newAriaExpanded = initialAriaExpanded === 'true' ? 'false' : 'true';
          trigger.setAttribute('aria-expanded', newAriaExpanded);
          
          // Check that aria-expanded toggled correctly
          if (initialAriaExpanded === 'true') {
            return newAriaExpanded === 'false';
          } else {
            return newAriaExpanded === 'true';
          }
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should ensure aria-expanded matches is-open class state', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 0, max: 3 }), // Generate random accordion item indices (0-3)
        (itemIndex) => {
          // Get all accordion items
          const items = container.querySelectorAll('.collection-accordion__item');
          const selectedItem = items[itemIndex];
          const trigger = selectedItem.querySelector('.collection-accordion__trigger');
          
          // Get initial state
          const wasOpen = selectedItem.classList.contains('is-open');
          
          // Simulate accordion behavior: toggle both class and aria-expanded together
          if (wasOpen) {
            selectedItem.classList.remove('is-open');
            trigger.setAttribute('aria-expanded', 'false');
          } else {
            selectedItem.classList.add('is-open');
            trigger.setAttribute('aria-expanded', 'true');
          }
          
          // Check that aria-expanded matches the is-open class
          const isOpen = selectedItem.classList.contains('is-open');
          const ariaExpanded = trigger.getAttribute('aria-expanded');
          
          return (isOpen && ariaExpanded === 'true') || (!isOpen && ariaExpanded === 'false');
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should close other accordion items when opening a new one', () => {
    fc.assert(
      fc.property(
        fc.tuple(
          fc.integer({ min: 0, max: 3 }), // First item to open
          fc.integer({ min: 0, max: 3 })  // Second item to open
        ).filter(([first, second]) => first !== second), // Ensure different items
        ([firstIndex, secondIndex]) => {
          const items = container.querySelectorAll('.collection-accordion__item');
          
          // Close all items first
          items.forEach(item => {
            item.classList.remove('is-open');
            const trigger = item.querySelector('.collection-accordion__trigger');
            trigger.setAttribute('aria-expanded', 'false');
          });
          
          // Open first item
          const firstItem = items[firstIndex];
          const firstTrigger = firstItem.querySelector('.collection-accordion__trigger');
          firstItem.classList.add('is-open');
          firstTrigger.setAttribute('aria-expanded', 'true');
          
          // Open second item (should close first)
          const secondItem = items[secondIndex];
          const secondTrigger = secondItem.querySelector('.collection-accordion__trigger');
          
          // Simulate the accordion behavior: close all, then open clicked
          items.forEach(item => {
            item.classList.remove('is-open');
            const trigger = item.querySelector('.collection-accordion__trigger');
            trigger.setAttribute('aria-expanded', 'false');
          });
          secondItem.classList.add('is-open');
          secondTrigger.setAttribute('aria-expanded', 'true');
          
          // Verify only the second item is open
          const openCount = Array.from(items).filter(item => 
            item.classList.contains('is-open')
          ).length;
          
          const firstIsOpen = firstItem.classList.contains('is-open');
          const secondIsOpen = secondItem.classList.contains('is-open');
          
          return openCount === 1 && !firstIsOpen && secondIsOpen;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should handle multiple sequential clicks on the same accordion item', () => {
    fc.assert(
      fc.property(
        fc.tuple(
          fc.integer({ min: 0, max: 3 }), // Accordion item index
          fc.integer({ min: 2, max: 5 })  // Number of clicks
        ),
        ([itemIndex, clickCount]) => {
          const items = container.querySelectorAll('.collection-accordion__item');
          const selectedItem = items[itemIndex];
          const trigger = selectedItem.querySelector('.collection-accordion__trigger');
          
          // Start with closed state
          selectedItem.classList.remove('is-open');
          trigger.setAttribute('aria-expanded', 'false');
          
          let expectedState = false;
          
          // Simulate multiple clicks
          for (let i = 0; i < clickCount; i++) {
            // Toggle state
            if (selectedItem.classList.contains('is-open')) {
              selectedItem.classList.remove('is-open');
              trigger.setAttribute('aria-expanded', 'false');
            } else {
              selectedItem.classList.add('is-open');
              trigger.setAttribute('aria-expanded', 'true');
            }
            expectedState = !expectedState;
          }
          
          // Verify final state matches expected
          const finalIsOpen = selectedItem.classList.contains('is-open');
          const finalAriaExpanded = trigger.getAttribute('aria-expanded') === 'true';
          
          return finalIsOpen === expectedState && finalAriaExpanded === expectedState;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should maintain correct aria-expanded for all items after multiple interactions', () => {
    fc.assert(
      fc.property(
        fc.array(fc.integer({ min: 0, max: 3 }), { minLength: 3, maxLength: 8 }), // Sequence of clicks
        (clickSequence) => {
          const items = container.querySelectorAll('.collection-accordion__item');
          
          // Simulate clicking items in sequence
          for (const index of clickSequence) {
            const item = items[index];
            const trigger = item.querySelector('.collection-accordion__trigger');
            
            // Simulate accordion behavior: close all, then open clicked if it was closed
            const wasOpen = item.classList.contains('is-open');
            
            items.forEach(i => {
              i.classList.remove('is-open');
              const t = i.querySelector('.collection-accordion__trigger');
              t.setAttribute('aria-expanded', 'false');
            });
            
            if (!wasOpen) {
              item.classList.add('is-open');
              trigger.setAttribute('aria-expanded', 'true');
            }
          }
          
          // Verify all items have consistent aria-expanded and is-open state
          let allConsistent = true;
          items.forEach(item => {
            const isOpen = item.classList.contains('is-open');
            const trigger = item.querySelector('.collection-accordion__trigger');
            const ariaExpanded = trigger.getAttribute('aria-expanded') === 'true';
            
            if (isOpen !== ariaExpanded) {
              allConsistent = false;
            }
          });
          
          return allConsistent;
        }
      ),
      { numRuns: 100 }
    );
  });
});
