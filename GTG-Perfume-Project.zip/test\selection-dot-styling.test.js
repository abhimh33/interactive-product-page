/**
 * Selection Dot Styling Tests
 * 
 * Feature: perfume-ui-redesign
 * Task: 8.4 Update selection dot styling
 * 
 * **Validates: Requirements 6.6, 6.7**
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';

describe('Selection Dot Styling', () => {
  let container;
  let style;

  beforeEach(() => {
    container = document.createElement('div');
    container.innerHTML = `
      <div class="product-scents">
        <label class="product-scent">
          <input type="radio" name="fragrance" value="original" />
          <span class="product-scent__card">
            <span class="product-scent__pick">
              <span class="product-scent__dot"></span> Original
            </span>
          </span>
        </label>
        <label class="product-scent">
          <input type="radio" name="fragrance" value="lily" checked />
          <span class="product-scent__card">
            <span class="product-scent__pick">
              <span class="product-scent__dot"></span> Lily
            </span>
          </span>
        </label>
      </div>
    `;
    document.body.appendChild(container);

    // Load the CSS styles inline
    style = document.createElement('style');
    style.textContent = `
      * {
        box-sizing: border-box;
      }
      
      .product-scent {
        position: relative;
      }

      .product-scent input {
        position: absolute;
        opacity: 0;
        pointer-events: none;
      }

      .product-scent__pick {
        display: flex;
        align-items: center;
        gap: 6px;
        font-size: 12px;
        font-weight: 600;
        color: #64748b;
      }

      .product-scent__dot {
        width: 14px;
        height: 14px;
        border-radius: 50%;
        border: 2px solid #064e22;
        box-sizing: border-box;
        flex-shrink: 0;
        display: grid;
        place-items: center;
      }

      .product-scent input:checked + .product-scent__card .product-scent__dot::after {
        content: "";
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background: #064e22;
      }
    `;
    document.head.appendChild(style);
  });

  afterEach(() => {
    document.body.removeChild(container);
    document.head.removeChild(style);
  });

  it('should set selection dot width to 14px', () => {
    const dot = container.querySelector('.product-scent__dot');
    const computedStyle = window.getComputedStyle(dot);
    
    expect(computedStyle.width).toBe('14px');
  });

  it('should set selection dot height to 14px', () => {
    const dot = container.querySelector('.product-scent__dot');
    const computedStyle = window.getComputedStyle(dot);
    
    expect(computedStyle.height).toBe('14px');
  });

  it('should set border to 2px solid #064e22', () => {
    const dot = container.querySelector('.product-scent__dot');
    const computedStyle = window.getComputedStyle(dot);
    
    expect(computedStyle.borderWidth).toBe('2px');
    expect(computedStyle.borderStyle).toBe('solid');
    // Browser may return color in different formats (rgb or hex)
    expect(['rgb(6, 78, 34)', '#064e22']).toContain(computedStyle.borderColor);
  });

  it('should set border-radius to 50%', () => {
    const dot = container.querySelector('.product-scent__dot');
    const computedStyle = window.getComputedStyle(dot);
    
    expect(computedStyle.borderRadius).toBe('50%');
  });

  it('should use box-sizing: border-box for accurate dimensions', () => {
    const dot = container.querySelector('.product-scent__dot');
    const computedStyle = window.getComputedStyle(dot);
    
    expect(computedStyle.boxSizing).toBe('border-box');
  });

  it('should use display: grid and place-items: center for centering the inner dot', () => {
    const dot = container.querySelector('.product-scent__dot');
    const computedStyle = window.getComputedStyle(dot);
    
    expect(computedStyle.display).toBe('grid');
    expect(computedStyle.placeItems).toBe('center');
  });

  it('should display inner dot when selected with width 8px, height 8px, background #064e22', () => {
    const checkedInput = container.querySelector('input[type="radio"]:checked');
    const card = checkedInput.nextElementSibling;
    const dot = card.querySelector('.product-scent__dot');
    
    // Verify the CSS rule is applied by checking the style element content
    const styleContent = style.textContent;
    expect(styleContent).toContain('.product-scent input:checked + .product-scent__card .product-scent__dot::after');
    expect(styleContent).toContain('width: 8px');
    expect(styleContent).toContain('height: 8px');
    expect(styleContent).toContain('background: #064e22');
    expect(styleContent).toContain('border-radius: 50%');
    
    // Verify the ::after pseudo-element exists
    const afterStyle = window.getComputedStyle(dot, '::after');
    expect(afterStyle.content).not.toBe('none');
  });

  it('should not display inner dot when unchecked', () => {
    const uncheckedInput = container.querySelector('input[type="radio"]:not(:checked)');
    const card = uncheckedInput.nextElementSibling;
    const dot = card.querySelector('.product-scent__dot');
    
    // Get the ::after pseudo-element styles
    const afterStyle = window.getComputedStyle(dot, '::after');
    
    // When unchecked, the ::after element should not have content or should be empty
    // Different browsers may return different values for non-existent pseudo-elements
    expect(['none', '', '""']).toContain(afterStyle.content);
  });

  it('should maintain consistent styling across multiple selection dots', () => {
    const allDots = container.querySelectorAll('.product-scent__dot');
    
    allDots.forEach(dot => {
      const computedStyle = window.getComputedStyle(dot);
      
      expect(computedStyle.width).toBe('14px');
      expect(computedStyle.height).toBe('14px');
      expect(computedStyle.borderWidth).toBe('2px');
      expect(['rgb(6, 78, 34)', '#064e22']).toContain(computedStyle.borderColor);
      expect(computedStyle.borderRadius).toBe('50%');
      expect(computedStyle.boxSizing).toBe('border-box');
    });
  });

  it('should properly center the inner dot within the outer circle', () => {
    const checkedInput = container.querySelector('input[type="radio"]:checked');
    const card = checkedInput.nextElementSibling;
    const dot = card.querySelector('.product-scent__dot');
    
    // The outer dot is 14px with 2px border, leaving 10px inner space
    // The inner dot is 8px, so it should have 1px margin on all sides
    // Using display: grid and place-items: center ensures perfect centering
    const computedStyle = window.getComputedStyle(dot);
    expect(computedStyle.display).toBe('grid');
    expect(computedStyle.placeItems).toBe('center');
  });
});
