/**
 * Price Display Tests
 * Feature: perfume-ui-redesign
 * Task: 7.5 Refine price display
 * 
 * **Validates: Requirements 5.5, 5.6**
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';

describe('Price Display', () => {
  let container;
  let style;

  beforeEach(() => {
    container = document.createElement('div');
    container.innerHTML = `
      <div class="product-sub product-sub--featured">
        <div class="product-sub__ribbon">Most Popular</div>
        <div class="product-sub__row product-sub__row--choice">
          <label class="product-radio">
            <input type="radio" name="purchase" value="single-sub" checked />
            <span class="product-radio__ui"></span>
            <span class="product-sub__plan-label">Single Subscription</span>
          </label>
          <div class="product-sub__prices">
            <span class="product-sub__price">$99.99</span>
            <span class="product-sub__was">$145</span>
          </div>
        </div>
      </div>
      <div class="product-sub product-sub--compact">
        <div class="product-sub__row product-sub__row--choice">
          <label class="product-radio">
            <input type="radio" name="purchase" value="double-sub" />
            <span class="product-radio__ui"></span>
            <span class="product-sub__plan-label">Double Subscription</span>
          </label>
          <div class="product-sub__prices">
            <span class="product-sub__price">$169.99</span>
            <span class="product-sub__was">$145</span>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(container);

    style = document.createElement('style');
    style.textContent = `
      .product-sub__prices {
        display: flex;
        align-items: center;
        gap: 8px;
        text-align: right;
        white-space: nowrap;
      }

      .product-sub__price {
        font-size: 18px;
        font-weight: 700;
        color: #111827;
      }

      .product-sub__was {
        font-size: 14px;
        color: #94a3b8;
        text-decoration: line-through;
      }
    `;
    document.head.appendChild(style);
  });

  afterEach(() => {
    document.body.removeChild(container);
    document.head.removeChild(style);
  });

  it('should apply font-size: 18px to current price', () => {
    const price = container.querySelector('.product-sub__price');
    const computedStyle = window.getComputedStyle(price);
    expect(computedStyle.fontSize).toBe('18px');
  });

  it('should apply font-weight: 700 to current price', () => {
    const price = container.querySelector('.product-sub__price');
    const computedStyle = window.getComputedStyle(price);
    expect(computedStyle.fontWeight).toBe('700');
  });

  it('should apply color: #111827 to current price', () => {
    const price = container.querySelector('.product-sub__price');
    const computedStyle = window.getComputedStyle(price);
    // Accept both hex and RGB formats
    expect(['#111827', 'rgb(17, 24, 39)']).toContain(computedStyle.color);
  });

  it('should apply font-size: 14px to strikethrough price', () => {
    const wasPrice = container.querySelector('.product-sub__was');
    const computedStyle = window.getComputedStyle(wasPrice);
    expect(computedStyle.fontSize).toBe('14px');
  });

  it('should apply color: #94a3b8 to strikethrough price', () => {
    const wasPrice = container.querySelector('.product-sub__was');
    const computedStyle = window.getComputedStyle(wasPrice);
    // Accept both hex and RGB formats
    expect(['#94a3b8', 'rgb(148, 163, 184)']).toContain(computedStyle.color);
  });

  it('should apply text-decoration: line-through to strikethrough price', () => {
    const wasPrice = container.querySelector('.product-sub__was');
    const computedStyle = window.getComputedStyle(wasPrice);
    expect(computedStyle.textDecoration).toContain('line-through');
  });

  it('should apply gap: 8px between prices', () => {
    const pricesContainer = container.querySelector('.product-sub__prices');
    const computedStyle = window.getComputedStyle(pricesContainer);
    expect(computedStyle.gap).toBe('8px');
  });

  it('should display prices in a flex container', () => {
    const pricesContainer = container.querySelector('.product-sub__prices');
    const computedStyle = window.getComputedStyle(pricesContainer);
    expect(computedStyle.display).toBe('flex');
  });

  it('should apply consistent styling to all price displays', () => {
    const allPrices = container.querySelectorAll('.product-sub__price');
    
    allPrices.forEach(price => {
      const computedStyle = window.getComputedStyle(price);
      expect(computedStyle.fontSize).toBe('18px');
      expect(computedStyle.fontWeight).toBe('700');
      expect(['#111827', 'rgb(17, 24, 39)']).toContain(computedStyle.color);
    });
  });

  it('should apply consistent styling to all strikethrough prices', () => {
    const allWasPrices = container.querySelectorAll('.product-sub__was');
    
    allWasPrices.forEach(wasPrice => {
      const computedStyle = window.getComputedStyle(wasPrice);
      expect(computedStyle.fontSize).toBe('14px');
      expect(['#94a3b8', 'rgb(148, 163, 184)']).toContain(computedStyle.color);
      expect(computedStyle.textDecoration).toContain('line-through');
    });
  });
});
