/**
 * Form Element Spacing Tests
 * Feature: perfume-ui-redesign
 * 
 * **Validates: Requirements 4.6, 16.5**
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';

describe('Form Element Spacing', () => {
  let container;
  let style;

  beforeEach(() => {
    // Create a fresh DOM structure for each test
    container = document.createElement('div');
    container.innerHTML = `
      <form class="product-form" data-product-form action="#" method="post">
        <div class="product-sub product-sub--featured">
          <div class="product-sub__ribbon">Most Popular</div>
          <div class="product-sub__row">Subscription 1</div>
        </div>
        <div class="product-sub product-sub--compact">
          <div class="product-sub__row">Subscription 2</div>
        </div>
        <a class="btn product-panel__cta" href="#">Add to Cart</a>
      </form>
    `;
    document.body.appendChild(container);

    // Load the CSS styles
    style = document.createElement('style');
    style.textContent = `
      .product-form {
        display: flex;
        flex-direction: column;
        gap: 16px;
      }
      
      .product-sub {
        border: 1px solid #e2e8f0;
        border-radius: 12px;
        overflow: hidden;
        background: #ffffff;
      }
    `;
    document.head.appendChild(style);
  });

  afterEach(() => {
    if (container && container.parentNode) {
      container.parentNode.removeChild(container);
    }
    if (style && style.parentNode) {
      style.parentNode.removeChild(style);
    }
  });

  it('should apply gap: 16px between form elements', () => {
    const form = container.querySelector('.product-form');
    const computedStyle = window.getComputedStyle(form);
    
    // Verify the form has display: flex
    expect(computedStyle.display).toBe('flex');
    
    // Verify the form has flex-direction: column
    expect(computedStyle.flexDirection).toBe('column');
    
    // Verify the form has gap: 16px
    expect(computedStyle.gap).toBe('16px');
  });

  it('should have correct spacing between subscription panels', () => {
    // Get both subscription panels
    const featuredPanel = container.querySelector('.product-sub--featured');
    const compactPanel = container.querySelector('.product-sub--compact');
    
    // Verify they exist
    expect(featuredPanel).toBeTruthy();
    expect(compactPanel).toBeTruthy();
    
    // Verify they are children of the product form
    const form = container.querySelector('.product-form');
    expect(form.contains(featuredPanel)).toBe(true);
    expect(form.contains(compactPanel)).toBe(true);
  });

  it('should have correct spacing between last subscription panel and CTA button', () => {
    const form = container.querySelector('.product-form');
    const ctaButton = container.querySelector('.product-panel__cta');
    
    // Verify the CTA button is a child of the product form
    expect(form.contains(ctaButton)).toBe(true);
    
    // Verify the button comes after the subscription panels
    const children = Array.from(form.children);
    const lastChild = children[children.length - 1];
    expect(lastChild.classList.contains('product-panel__cta')).toBe(true);
  });

  it('should maintain 16px gap with different numbers of form elements', () => {
    // Test with just two elements
    const form = container.querySelector('.product-form');
    const compactPanel = container.querySelector('.product-sub--compact');
    compactPanel.remove();
    
    const computedStyle = window.getComputedStyle(form);
    expect(computedStyle.gap).toBe('16px');
    
    // Gap should remain consistent regardless of number of children
    expect(computedStyle.display).toBe('flex');
    expect(computedStyle.flexDirection).toBe('column');
  });
});
