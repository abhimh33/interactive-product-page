/**
 * Unit Tests for Hero 900px Breakpoint Styles
 * 
 * **Validates: Requirements 11.4**
 * 
 * This test verifies that the hero section adjusts correctly at the 900px breakpoint:
 * - Hero height changes to auto with min-height: 640px
 * - Hero content positioning is updated with responsive margins
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';

describe('Hero 900px Breakpoint', () => {
  let container;
  let styleElement;

  beforeEach(() => {
    // Create a fresh DOM structure for each test
    container = document.createElement('div');
    container.innerHTML = `
      <section class="hero">
        <div class="hero__shell container">
          <header class="hero__nav">
            <div class="nav__left">
              <a class="logo" href="#">GTG</a>
            </div>
            <nav class="nav">
              <ul class="nav__list">
                <li><a href="#">Home</a></li>
              </ul>
            </nav>
          </header>
          <div class="hero__grid">
            <div class="hero__content">
              <h1 class="hero__title">Live your best life.</h1>
              <div class="hero__stats">
                <div class="stat-block">
                  <span class="stat-block__value">10x</span>
                  <span class="stat-block__label">power</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    `;
    document.body.appendChild(container);

    // Load the CSS styles for the 900px breakpoint
    styleElement = document.createElement('style');
    styleElement.textContent = `
      .hero {
        height: 794px;
        min-height: auto;
      }
      
      .hero__shell {
        height: 794px;
      }
      
      .hero__nav {
        position: absolute;
        top: 21px;
        left: 53px;
        right: 53px;
      }
      
      .hero__content {
        position: absolute;
        top: 177.5px;
        left: 74px;
        width: 692px;
        margin-left: 0;
        margin-right: 0;
        padding-top: 0;
      }
      
      .hero__title {
        font-size: 56px;
        line-height: 1.12;
      }
      
      .stat-block__value {
        font-size: 72px;
        line-height: 1;
      }
      
      @media (max-width: 900px) {
        .hero {
          height: auto;
          min-height: 640px;
        }
        
        .hero__shell {
          height: auto;
          min-height: 640px;
          padding-bottom: 40px;
        }
        
        .hero__nav {
          position: relative;
          top: 0;
          left: 0;
          right: 0;
          margin: 16px 16px 0;
        }
        
        .hero__content {
          margin-left: 24px;
          margin-right: 24px;
          padding-top: 48px;
          max-width: none;
        }
        
        .hero__title {
          font-size: 40px;
          line-height: 1.12;
        }
        
        .stat-block__value {
          font-size: 48px;
          line-height: 1;
        }
      }
    `;
    document.head.appendChild(styleElement);
  });

  afterEach(() => {
    document.body.removeChild(container);
    document.head.removeChild(styleElement);
  });

  it('should adjust hero height to auto with min-height 640px at 900px', () => {
    // Set viewport width to 900px
    Object.defineProperty(window, 'innerWidth', {
      writable: true,
      configurable: true,
      value: 900,
    });

    const hero = container.querySelector('.hero');
    const styles = window.getComputedStyle(hero);

    // At 900px, hero should have auto height with min-height 640px
    expect(styles.height).toBe('auto');
    expect(parseInt(styles.minHeight)).toBeGreaterThanOrEqual(640);
  });

  it('should update hero shell height at 900px breakpoint', () => {
    Object.defineProperty(window, 'innerWidth', {
      writable: true,
      configurable: true,
      value: 900,
    });

    const heroShell = container.querySelector('.hero__shell');
    const styles = window.getComputedStyle(heroShell);

    expect(styles.height).toBe('auto');
    expect(parseInt(styles.minHeight)).toBeGreaterThanOrEqual(640);
  });

  it('should update hero content positioning at 900px breakpoint', () => {
    Object.defineProperty(window, 'innerWidth', {
      writable: true,
      configurable: true,
      value: 900,
    });

    const heroContent = container.querySelector('.hero__content');
    const styles = window.getComputedStyle(heroContent);

    // Content should have responsive margins
    expect(parseInt(styles.marginLeft)).toBe(24);
    expect(parseInt(styles.marginRight)).toBe(24);
    expect(parseInt(styles.paddingTop)).toBe(48);
  });

  it('should adjust hero navigation to relative positioning at 900px', () => {
    Object.defineProperty(window, 'innerWidth', {
      writable: true,
      configurable: true,
      value: 900,
    });

    const heroNav = container.querySelector('.hero__nav');
    const styles = window.getComputedStyle(heroNav);

    expect(styles.position).toBe('relative');
    expect(parseInt(styles.top)).toBe(0);
    expect(parseInt(styles.left)).toBe(0);
    expect(parseInt(styles.right)).toBe(0);
  });

  it('should reduce hero title font size at 900px breakpoint', () => {
    Object.defineProperty(window, 'innerWidth', {
      writable: true,
      configurable: true,
      value: 900,
    });

    const heroTitle = container.querySelector('.hero__title');
    const styles = window.getComputedStyle(heroTitle);

    expect(parseInt(styles.fontSize)).toBe(40);
  });

  it('should reduce stat block value font size at 900px breakpoint', () => {
    Object.defineProperty(window, 'innerWidth', {
      writable: true,
      configurable: true,
      value: 900,
    });

    const statValue = container.querySelector('.stat-block__value');
    const styles = window.getComputedStyle(statValue);

    expect(parseInt(styles.fontSize)).toBe(48);
  });

  it('should maintain hero height at 794px above 900px', () => {
    Object.defineProperty(window, 'innerWidth', {
      writable: true,
      configurable: true,
      value: 1024,
    });

    const hero = container.querySelector('.hero');
    const styles = window.getComputedStyle(hero);

    expect(parseInt(styles.height)).toBe(794);
  });

  it('should maintain absolute positioning for hero content above 900px', () => {
    Object.defineProperty(window, 'innerWidth', {
      writable: true,
      configurable: true,
      value: 1024,
    });

    const heroContent = container.querySelector('.hero__content');
    const styles = window.getComputedStyle(heroContent);

    expect(styles.position).toBe('absolute');
    expect(parseFloat(styles.top)).toBe(177.5);
    expect(parseInt(styles.left)).toBe(74);
  });
});
