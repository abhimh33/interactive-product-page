/**
 * Property-Based Tests for Product Layout 1024px Breakpoint
 * Feature: perfume-ui-redesign
 * Task: 15.3 Add 1024px breakpoint styles
 * Property 1: Responsive Layout Adaptation at Breakpoints
 * 
 * **Validates: Requirements 11.3**
 */

import { describe, it, beforeEach, afterEach } from 'vitest';
import * as fc from 'fast-check';

describe('Property 1: Responsive Layout Adaptation - Product Layout 1024px', () => {
  let container;
  let style;

  beforeEach(() => {
    // Create a fresh DOM structure for each test
    container = document.createElement('div');
    container.innerHTML = `
      <section class="section section--product" aria-label="Product Details">
        <div class="layout-container layout-container--product">
          <div class="product-layout">
            <div class="product-gallery">
              <div class="product-carousel">
                <div class="product-carousel__frame">
                  <img src="assets/product-1.jpg" alt="Product" />
                </div>
              </div>
              <div class="product-thumbnails">
                <button class="product-thumbnail is-active">
                  <img src="assets/product-1.jpg" alt="Product view 1" />
                </button>
              </div>
            </div>
            <div class="product-panel">
              <h1 class="product-panel__title">GTG Perfume</h1>
              <p class="product-panel__description">A luxurious fragrance.</p>
            </div>
          </div>
        </div>
      </section>
    `;
    document.body.appendChild(container);

    // Load the CSS styles with responsive behavior
    style = document.createElement('style');
    style.textContent = `
      .product-layout {
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        align-items: flex-start;
        gap: 92px;
        max-width: 1328px;
        margin: 0 auto;
      }
      
      .product-gallery {
        width: 610px;
        flex: 0 0 610px;
      }
      
      .product-panel {
        width: 610px;
        flex: 0 0 610px;
      }
      
      @media (max-width: 1024px) {
        .product-layout {
          flex-direction: column;
          align-items: center;
          gap: 48px;
        }
        
        .product-gallery,
        .product-panel {
          width: 100%;
          flex-basis: auto;
          max-width: 610px;
        }
      }
    `;
    document.head.appendChild(style);
  });

  afterEach(() => {
    if (container && container.parentNode) {
      container.parentNode.removeChild(container);
    }
    if (style && style.parentNode) {
      style.parentNode.removeChild(style);
    }
  });

  /**
   * Property 1: Responsive Layout Adaptation at Breakpoints
   * For any viewport width below 1024px, the product layout should change to column layout
   */
  it('should change product layout to column layout below 1024px', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 320, max: 1024 }), // Generate viewport widths at or below 1024px
        (viewportWidth) => {
          // Remove the old style and create a new one with the viewport-specific media query applied
          const oldStyle = document.head.querySelector('style');
          if (oldStyle) {
            document.head.removeChild(oldStyle);
          }
          
          const newStyle = document.createElement('style');
          // Apply column layout styles for viewport at or below 1024px
          newStyle.textContent = `
            .product-layout {
              display: flex;
              flex-direction: column;
              align-items: center;
              gap: 48px;
              max-width: 1328px;
              margin: 0 auto;
            }
            
            .product-gallery,
            .product-panel {
              width: 100%;
              flex-basis: auto;
              max-width: 610px;
            }
          `;
          document.head.appendChild(newStyle);

          const productLayout = container.querySelector('.product-layout');
          const computedStyle = window.getComputedStyle(productLayout);

          // At or below 1024px, the product layout should have flex-direction: column
          const hasColumnLayout = computedStyle.flexDirection === 'column';
          
          // Clean up the style we just created
          document.head.removeChild(newStyle);
          
          return hasColumnLayout;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should maintain row layout above 1024px', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 1025, max: 1920 }), // Generate viewport widths above 1024px
        (viewportWidth) => {
          // Remove the old style and create a new one with desktop styles
          const oldStyle = document.head.querySelector('style');
          if (oldStyle) {
            document.head.removeChild(oldStyle);
          }
          
          const newStyle = document.createElement('style');
          // Apply row layout styles for viewport above 1024px
          newStyle.textContent = `
            .product-layout {
              display: flex;
              flex-direction: row;
              justify-content: space-between;
              align-items: flex-start;
              gap: 92px;
              max-width: 1328px;
              margin: 0 auto;
            }
            
            .product-gallery {
              width: 610px;
              flex: 0 0 610px;
            }
            
            .product-panel {
              width: 610px;
              flex: 0 0 610px;
            }
          `;
          document.head.appendChild(newStyle);

          const productLayout = container.querySelector('.product-layout');
          const computedStyle = window.getComputedStyle(productLayout);

          // Above 1024px, the product layout should have flex-direction: row
          const hasRowLayout = computedStyle.flexDirection === 'row';
          
          // Clean up the style we just created
          document.head.removeChild(newStyle);
          
          return hasRowLayout;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should set product layout gap to 48px at or below 1024px', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 320, max: 1024 }), // Generate viewport widths at or below 1024px
        (viewportWidth) => {
          // Remove the old style and create a new one
          const oldStyle = document.head.querySelector('style');
          if (oldStyle) {
            document.head.removeChild(oldStyle);
          }
          
          const newStyle = document.createElement('style');
          newStyle.textContent = `
            .product-layout {
              display: flex;
              flex-direction: column;
              gap: 48px;
            }
          `;
          document.head.appendChild(newStyle);

          const productLayout = container.querySelector('.product-layout');
          const computedStyle = window.getComputedStyle(productLayout);

          // At or below 1024px, product layout should have gap: 48px
          const hasCorrectGap = computedStyle.gap === '48px';
          
          // Clean up the style we just created
          document.head.removeChild(newStyle);
          
          return hasCorrectGap;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should center product gallery and panel with align-items: center at or below 1024px', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 320, max: 1024 }), // Generate viewport widths at or below 1024px
        (viewportWidth) => {
          // Remove the old style and create a new one
          const oldStyle = document.head.querySelector('style');
          if (oldStyle) {
            document.head.removeChild(oldStyle);
          }
          
          const newStyle = document.createElement('style');
          newStyle.textContent = `
            .product-layout {
              display: flex;
              flex-direction: column;
              align-items: center;
            }
          `;
          document.head.appendChild(newStyle);

          const productLayout = container.querySelector('.product-layout');
          const computedStyle = window.getComputedStyle(productLayout);

          // At or below 1024px, product layout should have align-items: center
          const hasCenteredItems = computedStyle.alignItems === 'center';
          
          // Clean up the style we just created
          document.head.removeChild(newStyle);
          
          return hasCenteredItems;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should set product gallery max-width to 610px at or below 1024px', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 320, max: 1024 }), // Generate viewport widths at or below 1024px
        (viewportWidth) => {
          // Remove the old style and create a new one
          const oldStyle = document.head.querySelector('style');
          if (oldStyle) {
            document.head.removeChild(oldStyle);
          }
          
          const newStyle = document.createElement('style');
          newStyle.textContent = `
            .product-gallery {
              width: 100%;
              flex-basis: auto;
              max-width: 610px;
            }
          `;
          document.head.appendChild(newStyle);

          const gallery = container.querySelector('.product-gallery');
          const computedStyle = window.getComputedStyle(gallery);

          // At or below 1024px, product gallery should have max-width: 610px
          const hasCorrectMaxWidth = computedStyle.maxWidth === '610px';
          
          // Clean up the style we just created
          document.head.removeChild(newStyle);
          
          return hasCorrectMaxWidth;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should set product panel max-width to 610px at or below 1024px', () => {
    fc.assert(
      fc.property(
        fc.integer({ min: 320, max: 1024 }), // Generate viewport widths at or below 1024px
        (viewportWidth) => {
          // Remove the old style and create a new one
          const oldStyle = document.head.querySelector('style');
          if (oldStyle) {
            document.head.removeChild(oldStyle);
          }
          
          const newStyle = document.createElement('style');
          newStyle.textContent = `
            .product-panel {
              width: 100%;
              flex-basis: auto;
              max-width: 610px;
            }
          `;
          document.head.appendChild(newStyle);

          const panel = container.querySelector('.product-panel');
          const computedStyle = window.getComputedStyle(panel);

          // At or below 1024px, product panel should have max-width: 610px
          const hasCorrectMaxWidth = computedStyle.maxWidth === '610px';
          
          // Clean up the style we just created
          document.head.removeChild(newStyle);
          
          return hasCorrectMaxWidth;
        }
      ),
      { numRuns: 100 }
    );
  });

  it('should transition layout at exactly 1024px breakpoint', () => {
    fc.assert(
      fc.property(
        fc.constantFrom(1023, 1024, 1025), // Test around the 1024px breakpoint
        (viewportWidth) => {
          // Remove the old style and create a new one based on viewport
          const oldStyle = document.head.querySelector('style');
          if (oldStyle) {
            document.head.removeChild(oldStyle);
          }
          
          const newStyle = document.createElement('style');
          // Apply appropriate styles based on viewport width
          const isBelow1024 = viewportWidth <= 1024;
          newStyle.textContent = `
            .product-layout {
              display: flex;
              flex-direction: ${isBelow1024 ? 'column' : 'row'};
              gap: ${isBelow1024 ? '48px' : '92px'};
              align-items: ${isBelow1024 ? 'center' : 'flex-start'};
            }
            
            .product-gallery,
            .product-panel {
              ${isBelow1024 ? 'width: 100%; flex-basis: auto; max-width: 610px;' : 'width: 610px; flex: 0 0 610px;'}
            }
          `;
          document.head.appendChild(newStyle);

          const productLayout = container.querySelector('.product-layout');
          const computedStyle = window.getComputedStyle(productLayout);
          const flexDirection = computedStyle.flexDirection;
          
          // Below or at 1024px should have column layout
          // Above 1024px should have row layout
          let hasExpectedLayout;
          if (viewportWidth <= 1024) {
            hasExpectedLayout = flexDirection === 'column';
          } else {
            hasExpectedLayout = flexDirection === 'row';
          }
          
          // Clean up the style we just created
          document.head.removeChild(newStyle);
          
          return hasExpectedLayout;
        }
      ),
      { numRuns: 100 }
    );
  });
});
