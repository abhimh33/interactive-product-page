/**
 * Radio Button Styling Tests
 * 
 * Feature: perfume-ui-redesign
 * Task: 7.4 Update radio button styling
 * 
 * **Validates: Requirements 5.4, 15.6**
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';

describe('Radio Button Styling', () => {
  let container;
  let style;

  beforeEach(() => {
    container = document.createElement('div');
    container.innerHTML = `
      <div class="product-sub">
        <div class="product-sub__row">
          <label class="product-radio">
            <input type="radio" name="test" value="option1" checked />
            <span class="product-radio__ui"></span>
            <span>Option 1</span>
          </label>
        </div>
        <div class="product-sub__row">
          <label class="product-radio">
            <input type="radio" name="test" value="option2" />
            <span class="product-radio__ui"></span>
            <span>Option 2</span>
          </label>
        </div>
      </div>
    `;
    document.body.appendChild(container);

    // Load the CSS styles inline
    style = document.createElement('style');
    style.textContent = `
      * {
        box-sizing: border-box;
      }
      
      .product-radio {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        cursor: pointer;
        font-size: 15px;
        color: #334155;
      }

      .product-radio input {
        position: absolute;
        opacity: 0;
        pointer-events: none;
      }

      .product-radio__ui {
        width: 20px;
        height: 20px;
        border-radius: 50%;
        border: 2px solid #064e22;
        box-sizing: border-box;
        flex-shrink: 0;
        display: grid;
        place-items: center;
      }

      .product-radio input:checked + .product-radio__ui::after {
        content: "";
        width: 10px;
        height: 10px;
        border-radius: 50%;
        background: #064e22;
      }
    `;
    document.head.appendChild(style);
  });

  afterEach(() => {
    document.body.removeChild(container);
    document.head.removeChild(style);
  });

  it('should set radio button width to 20px', () => {
    const radioUI = container.querySelector('.product-radio__ui');
    const computedStyle = window.getComputedStyle(radioUI);
    
    expect(computedStyle.width).toBe('20px');
  });

  it('should set radio button height to 20px', () => {
    const radioUI = container.querySelector('.product-radio__ui');
    const computedStyle = window.getComputedStyle(radioUI);
    
    expect(computedStyle.height).toBe('20px');
  });

  it('should set border to 2px solid #064e22', () => {
    const radioUI = container.querySelector('.product-radio__ui');
    const computedStyle = window.getComputedStyle(radioUI);
    
    expect(computedStyle.borderWidth).toBe('2px');
    expect(computedStyle.borderStyle).toBe('solid');
    // Browser may return color in different formats (rgb or hex)
    expect(['rgb(6, 78, 34)', '#064e22']).toContain(computedStyle.borderColor);
  });

  it('should set border-radius to 50%', () => {
    const radioUI = container.querySelector('.product-radio__ui');
    const computedStyle = window.getComputedStyle(radioUI);
    
    // border-radius: 50% on a 20px element = 10px
    expect(computedStyle.borderRadius).toBe('50%');
  });

  it('should display inner dot when checked with width 10px, height 10px, background #064e22', () => {
    const checkedRadio = container.querySelector('input[type="radio"]:checked');
    const radioUI = checkedRadio.nextElementSibling;
    
    // Verify the CSS rule is applied by checking the style element content
    const styleContent = style.textContent;
    expect(styleContent).toContain('.product-radio input:checked + .product-radio__ui::after');
    expect(styleContent).toContain('width: 10px');
    expect(styleContent).toContain('height: 10px');
    expect(styleContent).toContain('background: #064e22');
    expect(styleContent).toContain('border-radius: 50%');
    
    // Verify the ::after pseudo-element exists
    const afterStyle = window.getComputedStyle(radioUI, '::after');
    expect(afterStyle.content).not.toBe('none');
  });

  it('should not display inner dot when unchecked', () => {
    const uncheckedRadio = container.querySelector('input[type="radio"]:not(:checked)');
    const radioUI = uncheckedRadio.nextElementSibling;
    
    // Get the ::after pseudo-element styles
    const afterStyle = window.getComputedStyle(radioUI, '::after');
    
    // When unchecked, the ::after element should not have content or should be empty
    // Different browsers may return different values for non-existent pseudo-elements
    expect(['none', '', '""']).toContain(afterStyle.content);
  });

  it('should use box-sizing: border-box for accurate dimensions', () => {
    const radioUI = container.querySelector('.product-radio__ui');
    const computedStyle = window.getComputedStyle(radioUI);
    
    expect(computedStyle.boxSizing).toBe('border-box');
  });

  it('should use display: grid and place-items: center for centering the inner dot', () => {
    const radioUI = container.querySelector('.product-radio__ui');
    const computedStyle = window.getComputedStyle(radioUI);
    
    expect(computedStyle.display).toBe('grid');
    expect(computedStyle.placeItems).toBe('center');
  });

  it('should maintain consistent styling across multiple radio buttons', () => {
    const allRadioUIs = container.querySelectorAll('.product-radio__ui');
    
    allRadioUIs.forEach(radioUI => {
      const computedStyle = window.getComputedStyle(radioUI);
      
      expect(computedStyle.width).toBe('20px');
      expect(computedStyle.height).toBe('20px');
      expect(computedStyle.borderWidth).toBe('2px');
      expect(['rgb(6, 78, 34)', '#064e22']).toContain(computedStyle.borderColor);
      expect(computedStyle.borderRadius).toBe('50%');
    });
  });
});
