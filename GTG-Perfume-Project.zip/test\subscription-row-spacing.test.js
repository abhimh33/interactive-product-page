/**
 * Subscription Row Spacing Tests
 * Feature: perfume-ui-redesign
 * Task: 7.3 Refine subscription row spacing
 * 
 * **Validates: Requirements 5.3**
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';

describe('Subscription Row Spacing', () => {
  let container;
  let style;

  beforeEach(() => {
    // Create a fresh DOM structure for each test
    container = document.createElement('div');
    container.innerHTML = `
      <div class="product-sub product-sub--featured">
        <div class="product-sub__ribbon">Most Popular</div>
        <div class="product-sub__row product-sub__row--choice">
          <label class="product-radio">
            <input type="radio" name="purchase" value="single-sub" checked />
            <span class="product-radio__ui"></span>
            <span class="product-sub__plan-label">Single Subscription</span>
          </label>
          <div class="product-sub__prices">
            <span class="product-sub__price">$99.99</span>
            <span class="product-sub__was">$145</span>
          </div>
        </div>
        <div class="product-sub__detail">
          <p>Subscription details</p>
        </div>
      </div>
      <div class="product-sub product-sub--compact">
        <div class="product-sub__row product-sub__row--choice">
          <label class="product-radio">
            <input type="radio" name="purchase" value="double-sub" />
            <span class="product-radio__ui"></span>
            <span class="product-sub__plan-label">Double Subscription</span>
          </label>
          <div class="product-sub__prices">
            <span class="product-sub__price">$169.99</span>
            <span class="product-sub__was">$145</span>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(container);

    // Load the CSS styles
    style = document.createElement('style');
    style.textContent = `
      .product-sub__row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
        padding: 18px 20px 0;
      }
      
      .product-sub__row--choice {
        border-bottom: 1px solid #e2e8f0;
        padding-bottom: 16px;
        margin-bottom: 4px;
      }
      
      .product-sub--compact .product-sub__row--choice {
        border-bottom: 0;
        margin-bottom: 0;
        padding-bottom: 18px;
      }
    `;
    document.head.appendChild(style);
  });

  afterEach(() => {
    if (container && container.parentNode) {
      container.parentNode.removeChild(container);
    }
    if (style && style.parentNode) {
      style.parentNode.removeChild(style);
    }
  });

  it('should apply padding: 18px 20px 0 to subscription rows', () => {
    const row = container.querySelector('.product-sub__row');
    const computedStyle = window.getComputedStyle(row);
    
    expect(computedStyle.paddingTop).toBe('18px');
    expect(computedStyle.paddingRight).toBe('20px');
    // Note: padding-bottom is overridden by .product-sub__row--choice
    expect(computedStyle.paddingLeft).toBe('20px');
  });

  it('should apply border-bottom: 1px solid #e2e8f0 to choice rows', () => {
    const choiceRow = container.querySelector('.product-sub__row--choice');
    const computedStyle = window.getComputedStyle(choiceRow);
    
    expect(computedStyle.borderBottomWidth).toBe('1px');
    expect(computedStyle.borderBottomStyle).toBe('solid');
    // Browser returns color in different formats, just check it's set
    expect(computedStyle.borderBottomColor).toBeTruthy();
  });

  it('should apply padding-bottom: 16px to choice rows', () => {
    const choiceRow = container.querySelector('.product-sub__row--choice');
    const computedStyle = window.getComputedStyle(choiceRow);
    
    expect(computedStyle.paddingBottom).toBe('16px');
  });

  it('should apply correct spacing to featured subscription choice row', () => {
    const featuredChoiceRow = container.querySelector('.product-sub--featured .product-sub__row--choice');
    const computedStyle = window.getComputedStyle(featuredChoiceRow);
    
    // Verify all padding values
    expect(computedStyle.paddingTop).toBe('18px');
    expect(computedStyle.paddingRight).toBe('20px');
    expect(computedStyle.paddingBottom).toBe('16px');
    expect(computedStyle.paddingLeft).toBe('20px');
    
    // Verify border-bottom
    expect(computedStyle.borderBottomWidth).toBe('1px');
    expect(computedStyle.borderBottomStyle).toBe('solid');
    expect(computedStyle.borderBottomColor).toBeTruthy();
  });

  it('should apply correct spacing to compact subscription choice row', () => {
    const compactChoiceRow = container.querySelector('.product-sub--compact .product-sub__row--choice');
    const computedStyle = window.getComputedStyle(compactChoiceRow);
    
    // Verify padding values (compact has different padding-bottom)
    expect(computedStyle.paddingTop).toBe('18px');
    expect(computedStyle.paddingRight).toBe('20px');
    expect(computedStyle.paddingBottom).toBe('18px'); // Different for compact
    expect(computedStyle.paddingLeft).toBe('20px');
    
    // Verify no border-bottom for compact
    expect(computedStyle.borderBottomWidth).toBe('0px');
  });

  it('should maintain consistent horizontal padding across all subscription rows', () => {
    const allRows = container.querySelectorAll('.product-sub__row');
    
    allRows.forEach(row => {
      const computedStyle = window.getComputedStyle(row);
      expect(computedStyle.paddingLeft).toBe('20px');
      expect(computedStyle.paddingRight).toBe('20px');
    });
  });

  it('should maintain consistent top padding across all subscription rows', () => {
    const allRows = container.querySelectorAll('.product-sub__row');
    
    allRows.forEach(row => {
      const computedStyle = window.getComputedStyle(row);
      expect(computedStyle.paddingTop).toBe('18px');
    });
  });
});
