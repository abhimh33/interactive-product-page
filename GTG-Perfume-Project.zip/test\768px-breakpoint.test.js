/**
 * Unit Tests for 768px Breakpoint Styles
 * Feature: perfume-ui-redesign
 * Task 15.5: Add 768px breakpoint styles
 * 
 * **Validates: Requirements 11.5, 11.7**
 */

import { describe, it, expect, beforeEach } from 'vitest';
import fs from 'fs';
import path from 'path';

describe('768px Breakpoint Styles', () => {
  let cssContent;

  beforeEach(() => {
    // Read the CSS file
    cssContent = fs.readFileSync(path.resolve(__dirname, '../css/styles.css'), 'utf-8');
  });

  describe('CSS Breakpoint Implementation', () => {
    it('should have the 768px breakpoint media query in CSS', () => {
      expect(cssContent).toContain('@media');
      expect(cssContent).toMatch(/@media\s*\(max-width:\s*76[78]px\)/);
    });

    it('should display mobile navigation toggle below 768px', () => {
      // Extract the 767px/768px media query section
      const mediaQueryMatch = cssContent.match(/@media\s*\(max-width:\s*76[78]px\)\s*\{[\s\S]*?\n\}/);
      expect(mediaQueryMatch).toBeTruthy();
      
      const mobileStyles = mediaQueryMatch[0];
      expect(mobileStyles).toContain('.nav-toggle');
      expect(mobileStyles).toContain('display: block');
    });

    it('should hide desktop navigation below 768px', () => {
      const mediaQueryMatch = cssContent.match(/@media\s*\(max-width:\s*76[78]px\)\s*\{[\s\S]*?\n\}/);
      expect(mediaQueryMatch).toBeTruthy();
      
      const mobileStyles = mediaQueryMatch[0];
      expect(mobileStyles).toContain('.nav');
      expect(mobileStyles).toContain('display: none');
    });

    it('should update hero stats to flex-wrap below 768px', () => {
      const mediaQueryMatch = cssContent.match(/@media\s*\(max-width:\s*76[78]px\)\s*\{[\s\S]*?\n\}/);
      expect(mediaQueryMatch).toBeTruthy();
      
      const mobileStyles = mediaQueryMatch[0];
      expect(mobileStyles).toContain('.hero__stats');
      expect(mobileStyles).toContain('flex-wrap: wrap');
    });

    it('should change product included grid to single column below 768px', () => {
      const mediaQueryMatch = cssContent.match(/@media\s*\(max-width:\s*76[78]px\)\s*\{[\s\S]*?\n\}/);
      expect(mediaQueryMatch).toBeTruthy();
      
      const mobileStyles = mediaQueryMatch[0];
      expect(mobileStyles).toContain('.product-included');
      expect(mobileStyles).toContain('grid-template-columns: 1fr');
    });

    it('should change fragrance grid to 2 columns below 768px (Requirement 11.6)', () => {
      const mediaQueryMatch = cssContent.match(/@media\s*\(max-width:\s*76[78]px\)\s*\{[\s\S]*?\n\}/);
      expect(mediaQueryMatch).toBeTruthy();
      
      const mobileStyles = mediaQueryMatch[0];
      expect(mobileStyles).toContain('.product-scents');
      expect(mobileStyles).toContain('grid-template-columns: repeat(2, minmax(0, 1fr))');
    });

    it('should change stats banner to single column below 768px', () => {
      const mediaQueryMatch = cssContent.match(/@media\s*\(max-width:\s*76[78]px\)\s*\{[\s\S]*?\n\}/);
      expect(mediaQueryMatch).toBeTruthy();
      
      const mobileStyles = mediaQueryMatch[0];
      expect(mobileStyles).toContain('.stats-band__inner');
      expect(mobileStyles).toContain('grid-template-columns: 1fr');
    });

    it('should change footer grid to single column below 768px', () => {
      const mediaQueryMatch = cssContent.match(/@media\s*\(max-width:\s*76[78]px\)\s*\{[\s\S]*?\n\}/);
      expect(mediaQueryMatch).toBeTruthy();
      
      const mobileStyles = mediaQueryMatch[0];
      expect(mobileStyles).toContain('.footer__grid');
      expect(mobileStyles).toContain('grid-template-columns: 1fr');
    });

    it('should change footer form to column layout below 768px', () => {
      const mediaQueryMatch = cssContent.match(/@media\s*\(max-width:\s*76[78]px\)\s*\{[\s\S]*?\n\}/);
      expect(mediaQueryMatch).toBeTruthy();
      
      const mobileStyles = mediaQueryMatch[0];
      expect(mobileStyles).toContain('.footer__form');
      expect(mobileStyles).toContain('flex-direction: column');
    });
  });
});
