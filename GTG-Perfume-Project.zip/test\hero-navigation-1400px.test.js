/**
 * Unit Tests for Hero Navigation 1400px Breakpoint
 * Feature: perfume-ui-redesign
 * Task 15.1: Add 1400px breakpoint styles
 * 
 * **Validates: Requirements 11.1**
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import fs from 'fs';
import path from 'path';

describe('Hero Navigation 1400px Breakpoint', () => {
  let container;
  let style;

  beforeEach(() => {
    container = document.createElement('div');
    container.innerHTML = `
      <div class="hero">
        <div class="hero__shell">
          <header class="hero__nav">
            <a class="logo" href="#">GTG</a>
            <nav class="nav">
              <ul class="nav__list">
                <li><a href="#">Home</a></li>
                <li><a href="#">Shop</a></li>
              </ul>
            </nav>
            <div class="nav__right">
              <a class="btn btn--nav" href="#">Shop Now</a>
            </div>
          </header>
        </div>
      </div>
    `;
    document.body.appendChild(container);

    // Load the CSS styles inline with the 1400px breakpoint
    style = document.createElement('style');
    style.textContent = `
      .hero__nav {
        position: absolute;
        top: 21px;
        left: 53px;
        right: 53px;
        display: grid;
        grid-template-columns: auto 1fr auto;
        align-items: center;
        column-gap: 24px;
        z-index: 2;
      }

      @media (max-width: 1400px) {
        .hero__nav {
          left: 32px;
          right: 32px;
        }
      }
    `;
    document.head.appendChild(style);
  });

  afterEach(() => {
    document.body.removeChild(container);
    document.head.removeChild(style);
  });

  it('should have default positioning (left: 53px, right: 53px) in base styles', () => {
    const heroNav = container.querySelector('.hero__nav');
    const computedStyle = window.getComputedStyle(heroNav);
    
    // Check that the base styles are applied
    expect(computedStyle.position).toBe('absolute');
    expect(computedStyle.top).toBe('21px');
  });

  it('should verify the CSS rule exists in the actual stylesheet', () => {
    const css = fs.readFileSync(path.resolve(process.cwd(), 'css/styles.css'), 'utf-8');
    
    // Check that the 1400px media query exists
    expect(css).toContain('@media (max-width: 1400px)');
    
    // Check that it contains the hero__nav adjustments
    expect(css).toContain('.hero__nav');
    
    // Verify the specific positioning values
    const mediaQuerySection = css.match(/@media \(max-width: 1400px\)\s*\{[^}]*\.hero__nav[^}]*\}/s);
    expect(mediaQuerySection).toBeTruthy();
    expect(mediaQuerySection[0]).toContain('left: 32px');
    expect(mediaQuerySection[0]).toContain('right: 32px');
  });

  it('should have the correct structure for responsive navigation', () => {
    const heroNav = container.querySelector('.hero__nav');
    const computedStyle = window.getComputedStyle(heroNav);
    
    // Verify grid layout
    expect(computedStyle.display).toBe('grid');
    expect(computedStyle.gridTemplateColumns).toBe('auto 1fr auto');
    expect(computedStyle.alignItems).toBe('center');
    expect(computedStyle.columnGap).toBe('24px');
  });

  it('should maintain z-index for proper layering', () => {
    const heroNav = container.querySelector('.hero__nav');
    const computedStyle = window.getComputedStyle(heroNav);
    
    expect(computedStyle.zIndex).toBe('2');
  });

  it('should verify all required CSS properties are present', () => {
    const css = fs.readFileSync(path.resolve(process.cwd(), 'css/styles.css'), 'utf-8');
    
    // Check base hero__nav styles
    const baseNavRegex = /\.hero__nav\s*\{[^}]*position:\s*absolute[^}]*top:\s*21px[^}]*left:\s*53px[^}]*right:\s*53px[^}]*\}/s;
    expect(css).toMatch(baseNavRegex);
  });
});
