/**
 * Best-Seller Badge Tests
 * 
 * Feature: perfume-ui-redesign
 * Task: 8.3 Update best-seller badge
 * 
 * **Validates: Requirements 6.5**
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';

describe('Best-Seller Badge Styling', () => {
  let container;
  let style;

  beforeEach(() => {
    container = document.createElement('div');
    container.innerHTML = `
      <div class="product-scents">
        <label class="product-scent">
          <input type="radio" name="fragrance" value="original" />
          <span class="product-scent__card">
            <span class="product-scent__badge">BEST-SELLER</span>
            <span class="product-scent__pick">
              <span class="product-scent__dot"></span> Original
            </span>
            <span class="product-scent__img-wrap">
              <img src="test.png" alt="" class="product-scent__img" />
            </span>
          </span>
        </label>
      </div>
    `;
    document.body.appendChild(container);

    // Load the CSS styles inline
    style = document.createElement('style');
    style.textContent = `
      .product-scent {
        position: relative;
      }

      .product-scent__card {
        position: relative;
        display: flex;
        flex-direction: column;
        gap: 8px;
        padding: 10px 8px 12px;
        border-radius: 10px;
        border: 1px solid #e0e0e0;
        background: #f4f4f5;
        min-height: 148px;
      }

      .product-scent__badge {
        position: absolute;
        top: 8px;
        right: 8px;
        font-size: 9px;
        font-weight: 700;
        letter-spacing: 0.04em;
        color: #ffffff;
        background: #064e22;
        padding: 4px 6px;
        border-radius: 4px;
        line-height: 1;
      }
    `;
    document.head.appendChild(style);
  });

  afterEach(() => {
    document.body.removeChild(container);
    document.head.removeChild(style);
  });

  it('should position badge absolutely at top: 8px, right: 8px', () => {
    const badge = container.querySelector('.product-scent__badge');
    const computedStyle = window.getComputedStyle(badge);
    
    expect(computedStyle.position).toBe('absolute');
    expect(computedStyle.top).toBe('8px');
    expect(computedStyle.right).toBe('8px');
  });

  it('should set font-size to 9px', () => {
    const badge = container.querySelector('.product-scent__badge');
    const computedStyle = window.getComputedStyle(badge);
    
    expect(computedStyle.fontSize).toBe('9px');
  });

  it('should set font-weight to 700', () => {
    const badge = container.querySelector('.product-scent__badge');
    const computedStyle = window.getComputedStyle(badge);
    
    expect(computedStyle.fontWeight).toBe('700');
  });

  it('should set letter-spacing to 0.04em', () => {
    const badge = container.querySelector('.product-scent__badge');
    const computedStyle = window.getComputedStyle(badge);
    
    // letter-spacing: 0.04em is relative to font-size
    // Just verify it's set (browsers may compute the pixel value differently)
    expect(computedStyle.letterSpacing).not.toBe('normal');
    expect(computedStyle.letterSpacing).not.toBe('0px');
  });

  it('should set background color to #064e22', () => {
    const badge = container.querySelector('.product-scent__badge');
    const computedStyle = window.getComputedStyle(badge);
    
    // Browser may return color in different formats (rgb or hex)
    expect(['rgb(6, 78, 34)', '#064e22']).toContain(computedStyle.backgroundColor);
  });

  it('should set text color to #ffffff', () => {
    const badge = container.querySelector('.product-scent__badge');
    const computedStyle = window.getComputedStyle(badge);
    
    // Browser may return color in different formats
    expect(['rgb(255, 255, 255)', '#ffffff', 'white']).toContain(computedStyle.color);
  });

  it('should set padding to 4px 6px', () => {
    const badge = container.querySelector('.product-scent__badge');
    const computedStyle = window.getComputedStyle(badge);
    
    expect(computedStyle.paddingTop).toBe('4px');
    expect(computedStyle.paddingRight).toBe('6px');
    expect(computedStyle.paddingBottom).toBe('4px');
    expect(computedStyle.paddingLeft).toBe('6px');
  });

  it('should set border-radius to 4px', () => {
    const badge = container.querySelector('.product-scent__badge');
    const computedStyle = window.getComputedStyle(badge);
    
    expect(computedStyle.borderRadius).toBe('4px');
  });

  it('should set line-height to 1', () => {
    const badge = container.querySelector('.product-scent__badge');
    const computedStyle = window.getComputedStyle(badge);
    
    // line-height: 1 is unitless and may be returned as '1' or computed as '9px'
    expect(['1', '9px']).toContain(computedStyle.lineHeight);
  });

  it('should display badge text correctly', () => {
    const badge = container.querySelector('.product-scent__badge');
    
    expect(badge.textContent).toBe('BEST-SELLER');
  });

  it('should be positioned within the card container', () => {
    const card = container.querySelector('.product-scent__card');
    const badge = container.querySelector('.product-scent__badge');
    
    // Verify the badge is a child of the card
    expect(card.contains(badge)).toBe(true);
    
    // Verify the card has position: relative to contain the absolute badge
    const cardStyle = window.getComputedStyle(card);
    expect(cardStyle.position).toBe('relative');
  });

  it('should maintain consistent styling when card is selected', () => {
    // Simulate selection by adding checked attribute
    const input = container.querySelector('input[type="radio"]');
    input.checked = true;
    
    const badge = container.querySelector('.product-scent__badge');
    const computedStyle = window.getComputedStyle(badge);
    
    // Badge styling should remain the same regardless of card selection state
    expect(computedStyle.position).toBe('absolute');
    expect(computedStyle.top).toBe('8px');
    expect(computedStyle.right).toBe('8px');
    expect(computedStyle.fontSize).toBe('9px');
    expect(computedStyle.fontWeight).toBe('700');
    expect(['rgb(6, 78, 34)', '#064e22']).toContain(computedStyle.backgroundColor);
  });
});
