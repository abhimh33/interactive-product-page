/**
 * Test: Table Row Borders
 * Task: 12.7 Update table row borders
 * Requirements: 9.7
 * 
 * Validates that comparison table rows have the correct border styling
 * 
 * **Validates: Requirements 9.7**
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';

describe('Table Row Borders', () => {
  let container;
  let style;

  beforeEach(() => {
    container = document.createElement('div');
    container.innerHTML = `
      <table class="compare-table">
        <thead>
          <tr>
            <th class="compare-table__label">Qualities</th>
            <th class="compare-table__brand">GTG</th>
            <th class="compare-table__brand">Arose</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <th class="compare-table__row-label">Potency Concentration</th>
            <td class="compare-table__cell">10x</td>
            <td class="compare-table__cell">1x</td>
          </tr>
          <tr>
            <th class="compare-table__row-label">Longevity</th>
            <td class="compare-table__cell">Yes</td>
            <td class="compare-table__cell">No</td>
          </tr>
        </tbody>
      </table>
    `;
    document.body.appendChild(container);

    // Load the CSS styles inline
    style = document.createElement('style');
    style.textContent = `
      .compare-table {
        width: 100%;
        border-collapse: separate;
        border-spacing: 0;
        table-layout: fixed;
      }

      .compare-table th,
      .compare-table td {
        padding: 28px 16px;
        border-bottom: 1px solid #e0e0e0;
        vertical-align: middle;
      }

      .compare-table thead th {
        border-bottom: 1px solid #e0e0e0;
        padding-top: 32px;
        padding-bottom: 28px;
      }
    `;
    document.head.appendChild(style);
  });

  afterEach(() => {
    document.body.removeChild(container);
    document.head.removeChild(style);
  });

  it('should apply border-bottom: 1px solid #e0e0e0 to table cells', () => {
    const tableCells = container.querySelectorAll('.compare-table td');
    expect(tableCells.length).toBeGreaterThan(0);
    
    tableCells.forEach(cell => {
      const styles = window.getComputedStyle(cell);
      expect(styles.borderBottomWidth).toBe('1px');
      expect(styles.borderBottomStyle).toBe('solid');
      expect(['rgb(224, 224, 224)', '#e0e0e0']).toContain(styles.borderBottomColor);
    });
  });

  it('should apply border-bottom: 1px solid #e0e0e0 to table header cells', () => {
    const headerCells = container.querySelectorAll('.compare-table th');
    expect(headerCells.length).toBeGreaterThan(0);
    
    headerCells.forEach(cell => {
      const styles = window.getComputedStyle(cell);
      expect(styles.borderBottomWidth).toBe('1px');
      expect(styles.borderBottomStyle).toBe('solid');
      expect(['rgb(224, 224, 224)', '#e0e0e0']).toContain(styles.borderBottomColor);
    });
  });

  it('should have consistent border styling across all table rows', () => {
    const allCells = container.querySelectorAll('.compare-table th, .compare-table td');
    expect(allCells.length).toBeGreaterThan(0);
    
    allCells.forEach(cell => {
      const styles = window.getComputedStyle(cell);
      expect(styles.borderBottomWidth).toBe('1px');
      expect(styles.borderBottomStyle).toBe('solid');
      expect(['rgb(224, 224, 224)', '#e0e0e0']).toContain(styles.borderBottomColor);
    });
  });

  it('should apply correct padding to table cells', () => {
    const tableCells = container.querySelectorAll('.compare-table td');
    
    tableCells.forEach(cell => {
      const styles = window.getComputedStyle(cell);
      expect(styles.paddingTop).toBe('28px');
      expect(styles.paddingRight).toBe('16px');
      expect(styles.paddingBottom).toBe('28px');
      expect(styles.paddingLeft).toBe('16px');
    });
  });

  it('should apply correct padding to thead cells', () => {
    const headerCells = container.querySelectorAll('.compare-table thead th');
    
    headerCells.forEach(cell => {
      const styles = window.getComputedStyle(cell);
      expect(styles.paddingTop).toBe('32px');
      expect(styles.paddingBottom).toBe('28px');
    });
  });
});
